package com.foodalbum.app

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** catId == 0 means "All Recipes". */
@Composable
fun CategoryRecipesScreen(vm: AppViewModel, catId: Long, onBack: () -> Unit, onOpen: (Long) -> Unit) {
    val recipes by vm.recipes.collectAsState()
    val ings by vm.ingredientNames.collectAsState()
    val cats by vm.categories.collectAsState()
    val cat = cats.firstOrNull { it.id == catId }
    val all = recipes ?: emptyList()

    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(SortMode.RECENT) }

    // While the category row is still loading, show nothing instead of every recipe.
    val filterName: String? = if (catId == 0L) null else (cat?.name ?: "\u0000")
    val shown = remember(all, ings, query, sort, filterName) {
        filterAndSort(all, ings, query, filterName, sort)
    }
    val inCategory = all.count { filterName == null || it.category == filterName }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(if (catId == 0L) "All Recipes" else (cat?.name ?: ""), onBack = onBack) }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = gridPadding(pad),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            fullWidth { SearchField(query) { query = it } }
            fullWidth {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(recipeCount(shown.size), color = TextSecondary, fontSize = 14.sp)
                    SortMenu(sort) { sort = it }
                }
            }
            if (recipes != null && shown.isEmpty()) {
                fullWidth {
                    if (inCategory == 0) {
                        EmptyState("🍽️", "No recipes here yet", "Add a recipe and pick this category.")
                    } else {
                        EmptyState("🔎", "No matching recipes", "Try a different word.")
                    }
                }
            }
            recipeItems(shown, onOpen) { vm.toggleFavourite(it) }
        }
    }
}

@Composable
fun FavouritesScreen(vm: AppViewModel, onOpen: (Long) -> Unit, onTab: (String) -> Unit) {
    val recipes by vm.recipes.collectAsState()
    val favs = remember(recipes) {
        (recipes ?: emptyList()).filter { it.favourite }.sortedByDescending { it.createdAt }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { BottomNav("favourites", onTab) }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = gridPadding(pad),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            fullWidth {
                Column {
                    Text("Favourites", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                    Text(recipeCount(favs.size), color = TextSecondary, fontSize = 14.sp)
                }
            }
            if (recipes != null && favs.isEmpty()) {
                fullWidth {
                    EmptyState("❤️", "No favourites yet", "Tap the heart on a recipe to keep it here.")
                }
            }
            recipeItems(favs, onOpen) { vm.toggleFavourite(it) }
        }
    }
}
