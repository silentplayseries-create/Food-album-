package com.foodalbum.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

fun Ingredient.qtyText(): String =
    listOf(quantity, unit).filter { it.isNotBlank() }.joinToString(" ")

@Composable
fun AppTopBar(
    title: String,
    onBack: (() -> Unit)?,
    actions: @Composable RowScope.() -> Unit = {}
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .height(56.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
        } else {
            Spacer(Modifier.width(16.dp))
        }
        Text(
            text = title,
            modifier = Modifier.weight(1f),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        actions()
        Spacer(Modifier.width(4.dp))
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
}

@Composable
fun InfoPill(label: String, value: String) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(CardBg2)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    ) {
        Text("$label ", color = TextSecondary, fontSize = 13.sp)
        Text(value, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
    }
}

@Composable
fun IngredientRow(ing: Ingredient, large: Boolean, onToggle: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(14.dp)
    val checked = ing.checked
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(if (checked) Green.copy(alpha = 0.18f) else CardBg)
            .border(1.dp, if (checked) Green else BorderGrey, shape)
            .toggleable(value = checked, role = Role.Checkbox, onValueChange = onToggle)
            .heightIn(min = if (large) 68.dp else 54.dp)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(if (large) 36.dp else 30.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(if (checked) Green else Color.Transparent)
                .border(2.dp, if (checked) Green else TextSecondary, RoundedCornerShape(8.dp)),
            contentAlignment = Alignment.Center
        ) {
            if (checked) {
                Icon(
                    Icons.Default.Check,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(if (large) 26.dp else 20.dp)
                )
            }
        }
        Spacer(Modifier.width(12.dp))
        Text(
            text = ing.name,
            modifier = Modifier.weight(1f),
            fontSize = if (large) 20.sp else 16.sp
        )
        val q = ing.qtyText()
        if (q.isNotBlank()) {
            Spacer(Modifier.width(8.dp))
            Text(
                text = q,
                color = Gold,
                fontWeight = FontWeight.SemiBold,
                fontSize = if (large) 18.sp else 15.sp
            )
        }
    }
}

/**
 * The ingredient checklist (used on the details page and in Cooking Mode).
 * Ticking = "I have added this to the dish". Name and quantity always stay visible.
 */
@Composable
fun ChecklistBlock(
    ingredients: List<Ingredient>,
    large: Boolean,
    onToggle: (Ingredient, Boolean) -> Unit,
    onCheckAll: (() -> Unit)? = null,
    onReset: (() -> Unit)? = null
) {
    val total = ingredients.size
    if (total == 0) {
        Text("No ingredients added.", color = TextSecondary)
        return
    }
    val done = ingredients.count { it.checked }
    val allDone = done == total
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = "$done of $total ingredients added",
            fontWeight = FontWeight.SemiBold,
            fontSize = if (large) 18.sp else 15.sp,
            color = if (allDone) Green else MaterialTheme.colorScheme.onBackground
        )
        LinearProgressIndicator(
            progress = { done.toFloat() / total },
            modifier = Modifier
                .fillMaxWidth()
                .height(10.dp)
                .clip(RoundedCornerShape(5.dp)),
            color = if (allDone) Green else Orange,
            trackColor = CardBg2
        )
        ingredients.forEach { ing ->
            key(ing.id) {
                IngredientRow(ing, large) { onToggle(ing, it) }
            }
        }
        if (allDone) {
            Text(
                "All ingredients added! Continue with the cooking steps.",
                color = Green,
                fontWeight = FontWeight.SemiBold,
                fontSize = if (large) 18.sp else 15.sp
            )
        }
        if (onCheckAll != null || onReset != null) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (onCheckAll != null) {
                    OutlinedButton(onClick = onCheckAll, modifier = Modifier.weight(1f)) { Text("Check All") }
                }
                if (onReset != null) {
                    OutlinedButton(onClick = onReset, modifier = Modifier.weight(1f)) { Text("Reset Checklist") }
                }
            }
        }
    }
}
