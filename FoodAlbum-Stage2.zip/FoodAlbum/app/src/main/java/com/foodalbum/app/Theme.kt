package com.foodalbum.app

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Charcoal = Color(0xFF1A1A1D)
val CardBg = Color(0xFF242428)
val CardBg2 = Color(0xFF2E2E33)
val BorderGrey = Color(0xFF3F3F46)
val Orange = Color(0xFFFF8A1F)
val Gold = Color(0xFFFFC145)
val Green = Color(0xFF4CAF50)
val TextSecondary = Color(0xFFB0B0B8)
val Danger = Color(0xFFFF5252)

@Composable
fun FoodAlbumTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Orange,
            onPrimary = Color.Black,
            secondary = Gold,
            onSecondary = Color.Black,
            background = Charcoal,
            onBackground = Color.White,
            surface = CardBg,
            onSurface = Color.White,
            surfaceVariant = CardBg2,
            onSurfaceVariant = TextSecondary,
            outline = BorderGrey
        ),
        content = content
    )
}
