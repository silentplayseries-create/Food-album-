package com.foodalbum.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun CookingScreen(vm: AppViewModel, id: Long, onExit: () -> Unit) {
    val recipe by remember(id) { vm.recipe(id) }.collectAsState(initial = null)
    val ings by remember(id) { vm.ingredients(id) }.collectAsState(initial = emptyList())
    val steps by remember(id) { vm.steps(id) }.collectAsState(initial = emptyList())

    // Keep the screen awake while cooking.
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    val r = recipe
    // Current step lives in the database, so it survives leaving Cooking Mode / closing the app.
    val step = if (steps.isEmpty()) 0 else (r?.cookStep ?: 0).coerceIn(0, steps.size - 1)
    val isLast = steps.isNotEmpty() && step == steps.size - 1

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(title = r?.name ?: "", onBack = onExit) },
        bottomBar = {
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(CardBg)
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { vm.setCookStep(id, step - 1) },
                        enabled = step > 0,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                    ) { Text("Previous Step", fontSize = 16.sp) }
                    Button(
                        onClick = { vm.setCookStep(id, step + 1) },
                        enabled = steps.isNotEmpty() && !isLast,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black),
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp)
                    ) { Text("Next Step", fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                }
                TextButton(onClick = onExit, modifier = Modifier.fillMaxWidth()) {
                    Text("Exit Cooking Mode", color = TextSecondary)
                }
            }
        }
    ) { pad ->
        if (r != null) {
            Column(
                modifier = Modifier
                    .padding(pad)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Image or neutral placeholder
                val shape = RoundedCornerShape(18.dp)
                if (r.imagePath == null) {
                    ImagePlaceholder(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .clip(shape),
                        compact = true
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(CardBg),
                        contentAlignment = Alignment.Center
                    ) {
                        RecipeImage(
                            path = r.imagePath,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 100.dp, max = 240.dp),
                            contentScale = ContentScale.Fit,
                            minSide = 900
                        )
                    }
                }

                SectionTitle("Ingredients")
                ChecklistBlock(
                    ingredients = ings,
                    large = true,
                    onToggle = { ing, v -> vm.setChecked(ing, v) }
                )

                SectionTitle("Cooking Steps")
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg2),
                    border = BorderStroke(1.dp, Orange),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        if (steps.isEmpty()) {
                            Text("No cooking steps added for this recipe.", color = TextSecondary, fontSize = 18.sp)
                        } else {
                            Text(
                                "STEP ${step + 1} OF ${steps.size}",
                                color = Gold,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(steps[step].text, fontSize = 24.sp, lineHeight = 34.sp)
                            if (isLast) {
                                Text(
                                    "Recipe Completed!",
                                    color = Green,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 24.sp
                                )
                                OutlinedButton(
                                    onClick = { vm.resetCooking(id) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Reset checklist for next session") }
                            }
                        }
                    }
                }
            }
        }
    }
}
