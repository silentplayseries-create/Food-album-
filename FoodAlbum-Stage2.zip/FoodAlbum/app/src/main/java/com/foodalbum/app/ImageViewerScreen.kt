package com.foodalbum.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContract
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Lets the user choose where to save: input = (suggested file name, mime type). */
class CreateImageDocument : ActivityResultContract<Pair<String, String>, Uri?>() {
    override fun createIntent(context: Context, input: Pair<String, String>): Intent =
        Intent(Intent.ACTION_CREATE_DOCUMENT)
            .addCategory(Intent.CATEGORY_OPENABLE)
            .setType(input.second)
            .putExtra(Intent.EXTRA_TITLE, input.first)

    override fun parseResult(resultCode: Int, intent: Intent?): Uri? =
        if (resultCode == Activity.RESULT_OK) intent?.data else null
}

fun imageMime(path: String): String {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, o)
    return o.outMimeType ?: "image/jpeg"
}

fun extFor(mime: String): String = when (mime) {
    "image/jpeg" -> "jpg"
    "image/png" -> "png"
    "image/webp" -> "webp"
    "image/gif" -> "gif"
    "image/heic" -> "heic"
    "image/heif" -> "heif"
    else -> "jpg"
}

fun safeFileName(name: String): String {
    val s = name.trim().replace(Regex("[^A-Za-z0-9._-]+"), "_").trim('_')
    return if (s.isEmpty()) "recipe" else s.take(60)
}

@Composable
fun ImageViewerScreen(vm: AppViewModel, id: Long, onClose: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val recipe by remember(id) { vm.recipe(id) }.collectAsState(initial = null)
    val r = recipe
    val path = r?.imagePath
    val baseName = safeFileName(r?.name ?: "")

    // Image removed (or recipe gone) -> nothing left to view.
    LaunchedEffect(r != null, path) {
        if (r != null && path == null) onClose()
    }

    var scale by remember(path) { mutableFloatStateOf(1f) }
    var offset by remember(path) { mutableStateOf(Offset.Zero) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }

    fun clamp(o: Offset, s: Float): Offset {
        val mx = boxSize.width * (s - 1f) / 2f
        val my = boxSize.height * (s - 1f) / 2f
        return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.replaceImage(id, uri)
    }

    val saver = rememberLauncherForActivityResult(CreateImageDocument()) { uri ->
        val p = path
        if (uri != null && p != null) {
            scope.launch {
                val ok = withContext(Dispatchers.IO) {
                    try {
                        ctx.contentResolver.openOutputStream(uri)?.use { out ->
                            File(p).inputStream().use { it.copyTo(out) }
                        }
                        true
                    } catch (e: Exception) {
                        false
                    }
                }
                Toast.makeText(ctx, if (ok) "Image saved" else "Could not save image", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        if (path != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .onSizeChanged { boxSize = it }
                    .pointerInput(path) {
                        detectTapGestures(onDoubleTap = {
                            if (scale > 1.05f) {
                                scale = 1f
                                offset = Offset.Zero
                            } else {
                                scale = 2.5f
                            }
                        })
                    }
                    .pointerInput(path) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            val ns = (scale * zoom).coerceIn(1f, 6f)
                            scale = ns
                            offset = if (ns <= 1f) Offset.Zero else clamp(offset + pan, ns)
                        }
                    }
            ) {
                // The original file is never touched; zoom/pan only transform how it is drawn.
                RecipeImage(
                    path = path,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        },
                    contentScale = ContentScale.Fit,
                    minSide = 1400
                )
            }
        }

        IconButton(
            onClick = onClose,
            modifier = Modifier
                .align(Alignment.TopStart)
                .statusBarsPadding()
                .padding(8.dp)
                .background(Color.Black.copy(alpha = 0.5f), CircleShape)
        ) {
            Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
        }

        if (path != null) {
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .navigationBarsPadding()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val pad = PaddingValues(horizontal = 4.dp)
                OutlinedButton(
                    onClick = {
                        scope.launch {
                            try {
                                val mime = withContext(Dispatchers.IO) { imageMime(path) }
                                val uri = withContext(Dispatchers.IO) {
                                    val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
                                    val out = File(dir, "$baseName.${extFor(mime)}")
                                    File(path).copyTo(out, overwrite = true)
                                    FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", out)
                                }
                                val send = Intent(Intent.ACTION_SEND).apply {
                                    type = mime
                                    putExtra(Intent.EXTRA_STREAM, uri)
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                ctx.startActivity(Intent.createChooser(send, "Share image"))
                            } catch (e: Exception) {
                                Toast.makeText(ctx, "Could not share image", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    contentPadding = pad,
                    modifier = Modifier.weight(1f)
                ) { Text("Share", fontSize = 13.sp, color = Color.White) }
                OutlinedButton(
                    onClick = {
                        val mime = imageMime(path)
                        saver.launch(Pair("$baseName.${extFor(mime)}", mime))
                    },
                    contentPadding = pad,
                    modifier = Modifier.weight(1f)
                ) { Text("Save", fontSize = 13.sp, color = Color.White) }
                OutlinedButton(
                    onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    contentPadding = pad,
                    modifier = Modifier.weight(1f)
                ) { Text("Change", fontSize = 13.sp, color = Color.White) }
                OutlinedButton(
                    onClick = { vm.removeImage(id) },
                    contentPadding = pad,
                    modifier = Modifier.weight(1f)
                ) { Text("Remove", fontSize = 13.sp, color = Danger) }
            }
        }
    }
}
