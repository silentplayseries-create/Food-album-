package com.foodalbum.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch

@Composable
fun CategoriesScreen(vm: AppViewModel, onOpenCategory: (Long) -> Unit, onTab: (String) -> Unit) {
    val recipes by vm.recipes.collectAsState()
    val cats by vm.categories.collectAsState()
    val all = recipes ?: emptyList()
    val scope = rememberCoroutineScope()

    var creating by remember { mutableStateOf(false) }
    var renaming by remember { mutableStateOf<Category?>(null) }
    var deleting by remember { mutableStateOf<Category?>(null) }

    // Thumbnail = newest recipe of that category that really has an uploaded image.
    fun thumb(name: String?): String? =
        all.filter { (name == null || it.category == name) && it.imagePath != null }
            .maxByOrNull { it.createdAt }?.imagePath

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { BottomNav("categories", onTab) }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = gridPadding(pad),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            fullWidth {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Categories", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                        Text(recipeCount(all.size) + " in total", color = TextSecondary, fontSize = 14.sp)
                    }
                    Button(
                        onClick = { creating = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                    ) { Text("+ New", fontWeight = FontWeight.Bold) }
                }
            }
            item {
                CategoryCard(
                    name = "All Recipes",
                    count = all.size,
                    imagePath = thumb(null),
                    onClick = { onOpenCategory(0L) },
                    onRename = null,
                    onDelete = null
                )
            }
            items(cats, key = { it.id }) { c ->
                val isFixed = c.name == OTHER_CATEGORY
                CategoryCard(
                    name = c.name,
                    count = all.count { it.category == c.name },
                    imagePath = thumb(c.name),
                    onClick = { onOpenCategory(c.id) },
                    onRename = if (isFixed) null else ({ renaming = c }),
                    onDelete = if (isFixed) null else ({ deleting = c })
                )
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "New category",
            initial = "",
            confirmLabel = "Create",
            onDismiss = { creating = false },
            onConfirm = { n -> vm.addCategory(n) }
        )
    }

    renaming?.let { cat ->
        NameDialog(
            title = "Rename category",
            initial = cat.name,
            confirmLabel = "Rename",
            onDismiss = { renaming = null },
            onConfirm = { n -> vm.renameCategory(cat, n) }
        )
    }

    deleting?.let { cat ->
        val n = all.count { it.category == cat.name }
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete “${cat.name}”?") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (n == 0) {
                        Text("This category has no recipes.")
                    } else {
                        Text("${recipeCount(n)} in this category. Your recipes are kept unless you choose to delete them too.")
                        TextButton(onClick = {
                            scope.launch { vm.deleteCategory(cat, true) }
                            deleting = null
                        }) { Text("Delete category AND its recipes", color = Danger) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { vm.deleteCategory(cat, false) }
                    deleting = null
                }) { Text(if (n == 0) "Delete" else "Move recipes to Other Recipes") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun CategoryCard(
    name: String,
    count: Int,
    imagePath: String?,
    onClick: () -> Unit,
    onRename: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    val shape = RoundedCornerShape(18.dp)
    var menu by remember { mutableStateOf(false) }
    Card(
        modifier = Modifier
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderGrey)
    ) {
        Box {
            if (imagePath != null) {
                RecipeImage(
                    path = imagePath,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.3f),
                    contentScale = ContentScale.Crop,
                    minSide = 400,
                    compactPlaceholder = true
                )
            } else {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.3f)
                        .background(Brush.verticalGradient(listOf(CardBg2, CardBg))),
                    contentAlignment = Alignment.Center
                ) { Text("🍽️", fontSize = 36.sp) }
            }
            if (onRename != null || onDelete != null) {
                Box(Modifier.align(Alignment.TopEnd)) {
                    IconButton(
                        onClick = { menu = true },
                        modifier = Modifier
                            .padding(4.dp)
                            .size(36.dp)
                            .background(Color.Black.copy(alpha = 0.45f), CircleShape)
                    ) { Text("⋮", color = Color.White, fontSize = 18.sp) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        if (onRename != null) {
                            DropdownMenuItem(
                                text = { Text("Rename") },
                                onClick = {
                                    menu = false
                                    onRename()
                                }
                            )
                        }
                        if (onDelete != null) {
                            DropdownMenuItem(
                                text = { Text("Delete", color = Danger) },
                                onClick = {
                                    menu = false
                                    onDelete()
                                }
                            )
                        }
                    }
                }
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(recipeCount(count), color = TextSecondary, fontSize = 13.sp)
        }
    }
}
