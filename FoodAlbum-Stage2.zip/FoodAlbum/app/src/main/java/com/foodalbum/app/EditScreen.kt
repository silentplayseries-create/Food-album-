package com.foodalbum.app

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicLong

private fun <T> MutableList<T>.move(from: Int, to: Int) {
    if (from !in indices || to !in indices) return
    val item = removeAt(from)
    add(to, item)
}

@Composable
fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    minLines: Int = 1,
    isError: Boolean = false
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        modifier = modifier.fillMaxWidth(),
        singleLine = minLines == 1,
        minLines = minLines,
        isError = isError,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Orange,
            focusedLabelColor = Orange,
            cursorColor = Orange
        )
    )
}

@Composable
private fun MoveButtons(index: Int, count: Int, onUp: () -> Unit, onDown: () -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onUp, enabled = index > 0) {
            Text("▲", color = if (index > 0) Color.White else TextSecondary.copy(alpha = 0.3f))
        }
        IconButton(onClick = onDown, enabled = index < count - 1) {
            Text("▼", color = if (index < count - 1) Color.White else TextSecondary.copy(alpha = 0.3f))
        }
        IconButton(onClick = onDelete) { Text("✕", color = Danger, fontSize = 18.sp) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditScreen(vm: AppViewModel, id: Long, onClose: () -> Unit, onSaved: (Long) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val counter = remember { AtomicLong(0) }

    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var prep by remember { mutableStateOf("") }
    var cook by remember { mutableStateOf("") }
    var servings by remember { mutableStateOf("") }
    var difficulty by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    val ings = remember { mutableStateListOf<IngDraft>() }
    val steps = remember { mutableStateListOf<StepDraft>() }

    var existingPath by remember { mutableStateOf<String?>(null) }
    var stagedPath by remember { mutableStateOf<String?>(null) }
    var removedImage by remember { mutableStateOf(false) }

    var loaded by remember { mutableStateOf(id <= 0) }
    var saved by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var nameError by remember { mutableStateOf(false) }
    var catError by remember { mutableStateOf(false) }

    val cats by vm.categories.collectAsState()
    var newCatDialog by remember { mutableStateOf(false) }

    LaunchedEffect(id) {
        if (id > 0) {
            val d = vm.loadDraft(id)
            if (d != null) {
                val (r, il, sl) = d
                name = r.name
                category = r.category
                description = r.description
                prep = r.prepTime
                cook = r.cookTime
                servings = r.servings
                difficulty = r.difficulty
                notes = r.notes
                existingPath = r.imagePath
                il.forEach { ings.add(IngDraft(counter.incrementAndGet(), it.name, it.quantity, it.unit, it.checked)) }
                sl.forEach { steps.add(StepDraft(counter.incrementAndGet(), it.text)) }
            }
            if (ings.isEmpty()) ings.add(IngDraft(counter.incrementAndGet()))
            if (steps.isEmpty()) steps.add(StepDraft(counter.incrementAndGet()))
            loaded = true
        } else {
            ings.add(IngDraft(counter.incrementAndGet()))
            steps.add(StepDraft(counter.incrementAndGet()))
        }
    }

    // If the user leaves without saving, delete the image copy we staged.
    DisposableEffect(Unit) {
        onDispose {
            if (!saved) stagedPath?.let { File(it).delete() }
        }
    }

    val shownPath: String? = stagedPath ?: if (removedImage) null else existingPath

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            scope.launch {
                val p = vm.stageImage(uri)
                if (p == null) {
                    Toast.makeText(ctx, "Could not read that image", Toast.LENGTH_SHORT).show()
                } else {
                    stagedPath?.let { File(it).delete() }
                    stagedPath = p
                    removedImage = false
                }
            }
        }
    }
    val pickImage = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    if (newCatDialog) {
        NameDialog(
            title = "New category",
            initial = "",
            confirmLabel = "Create",
            onDismiss = { newCatDialog = false },
            onConfirm = { n ->
                val err = vm.addCategory(n)
                if (err == null) {
                    category = n.trim()
                    catError = false
                }
                err
            }
        )
    }

    Scaffold(
        modifier = Modifier.imePadding(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar(if (id > 0) "Edit Recipe" else "New Recipe", onBack = onClose) },
        bottomBar = {
            Box(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.background)
                    .navigationBarsPadding()
                    .padding(12.dp)
            ) {
                Button(
                    onClick = {
                        nameError = name.isBlank()
                        catError = category.isBlank()
                        if (nameError || catError) {
                            Toast.makeText(ctx, "Recipe name and category are required", Toast.LENGTH_SHORT).show()
                        } else {
                            saving = true
                            scope.launch {
                                val form = RecipeForm(
                                    name = name,
                                    category = category,
                                    description = description,
                                    prepTime = prep,
                                    cookTime = cook,
                                    servings = servings,
                                    difficulty = difficulty,
                                    notes = notes,
                                    imagePath = shownPath,
                                    ingredients = ings.toList(),
                                    steps = steps.map { it.text }
                                )
                                try {
                                    val newId = vm.saveRecipe(id, form)
                                    saved = true
                                    Toast.makeText(ctx, "Recipe saved", Toast.LENGTH_SHORT).show()
                                    onSaved(newId)
                                } catch (e: Exception) {
                                    saving = false
                                    Toast.makeText(ctx, "Could not save recipe", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    enabled = loaded && !saving,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                ) {
                    Text("Save Recipe", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---- Image ----
            val imgShape = RoundedCornerShape(20.dp)
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(230.dp)
                    .clip(imgShape)
                    .background(CardBg)
                    .border(1.dp, BorderGrey, imgShape)
                    .clickable { pickImage() },
                contentAlignment = Alignment.Center
            ) {
                if (shownPath != null) {
                    RecipeImage(
                        path = shownPath,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit,
                        minSide = 1000
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("📷", fontSize = 48.sp)
                        Text("Add Food Image", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Choose from Gallery", color = TextSecondary, fontSize = 14.sp)
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { pickImage() }, modifier = Modifier.weight(1f)) {
                    Text(if (shownPath == null) "Choose from Gallery" else "Change Image")
                }
                if (shownPath != null) {
                    OutlinedButton(
                        onClick = {
                            stagedPath?.let { File(it).delete() }
                            stagedPath = null
                            removedImage = true
                        },
                        modifier = Modifier.weight(1f)
                    ) { Text("Remove Image") }
                }
            }
            Text(
                "Image is optional. Without one, the recipe shows a neutral placeholder.",
                color = TextSecondary,
                fontSize = 12.sp
            )

            // ---- Basic info ----
            Field("Recipe Name *", name, { name = it; nameError = false }, isError = nameError)

            Text("Category *", fontWeight = FontWeight.SemiBold, color = if (catError) Danger else Color.White)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                cats.forEach { c ->
                    FilterChip(
                        selected = category == c.name,
                        onClick = { category = c.name; catError = false },
                        label = { Text(c.name) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Orange,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
                FilterChip(
                    selected = false,
                    onClick = { newCatDialog = true },
                    label = { Text("+ New") }
                )
            }

            Field("Short Description", description, { description = it }, minLines = 2)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field("Prep time", prep, { prep = it }, modifier = Modifier.weight(1f))
                Field("Cook time", cook, { cook = it }, modifier = Modifier.weight(1f))
            }
            Field("Serving size", servings, { servings = it })

            Text("Difficulty", fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Easy", "Medium", "Hard").forEach { d ->
                    FilterChip(
                        selected = difficulty == d,
                        onClick = { difficulty = if (difficulty == d) "" else d },
                        label = { Text(d) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Orange,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }

            // ---- Ingredients ----
            SectionTitle("Ingredients")
            Text(
                "Quantity can be text too: “to taste”, “as required”, “10–12”.",
                color = TextSecondary,
                fontSize = 12.sp
            )
            ings.forEachIndexed { i, d ->
                key(d.key) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg)
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Field("Ingredient name", d.name, { ings[i] = ings[i].copy(name = it) })
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Field("Quantity", d.quantity, { ings[i] = ings[i].copy(quantity = it) }, modifier = Modifier.weight(1f))
                                Field("Unit", d.unit, { ings[i] = ings[i].copy(unit = it) }, modifier = Modifier.weight(1f))
                            }
                            MoveButtons(
                                index = i,
                                count = ings.size,
                                onUp = { ings.move(i, i - 1) },
                                onDown = { ings.move(i, i + 1) },
                                onDelete = { ings.removeAt(i) }
                            )
                        }
                    }
                }
            }
            OutlinedButton(
                onClick = { ings.add(IngDraft(counter.incrementAndGet())) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ Add Ingredient") }

            // ---- Steps ----
            SectionTitle("Cooking Method")
            steps.forEachIndexed { i, s ->
                key(s.key) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg)
                    ) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Field("Step ${i + 1}", s.text, { steps[i] = steps[i].copy(text = it) }, minLines = 2)
                            MoveButtons(
                                index = i,
                                count = steps.size,
                                onUp = { steps.move(i, i - 1) },
                                onDown = { steps.move(i, i + 1) },
                                onDelete = { steps.removeAt(i) }
                            )
                        }
                    }
                }
            }
            OutlinedButton(
                onClick = { steps.add(StepDraft(counter.incrementAndGet())) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("+ Add Step") }

            // ---- Notes ----
            SectionTitle("Personal Notes")
            Field("Notes (optional)", notes, { notes = it }, minLines = 3)
        }
    }
}
