package com.foodalbum.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.layout.Box
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class SortMode(val label: String) {
    RECENT("Recently Added"),
    OLDEST("Oldest First"),
    AZ("Alphabetical A–Z"),
    VIEWED("Recently Viewed")
}

fun recipeCount(n: Int): String = if (n == 1) "1 recipe" else "$n recipes"

/**
 * Search matches recipe name, category, description, personal notes and ingredient names.
 * [category] = null means "all categories".
 */
fun filterAndSort(
    recipes: List<Recipe>,
    ingredients: List<IngName>,
    query: String,
    category: String?,
    sort: SortMode
): List<Recipe> {
    val q = query.trim().lowercase()
    val ingByRecipe: Map<Long, List<String>> =
        if (q.isEmpty()) emptyMap() else ingredients.groupBy({ it.recipeId }, { it.name.lowercase() })
    val filtered = recipes.filter { r ->
        (category == null || r.category == category) &&
            (q.isEmpty() ||
                r.name.lowercase().contains(q) ||
                r.category.lowercase().contains(q) ||
                r.notes.lowercase().contains(q) ||
                r.description.lowercase().contains(q) ||
                (ingByRecipe[r.id]?.any { it.contains(q) } == true))
    }
    return when (sort) {
        SortMode.RECENT -> filtered.sortedByDescending { it.createdAt }
        SortMode.OLDEST -> filtered.sortedBy { it.createdAt }
        SortMode.AZ -> filtered.sortedBy { it.name.lowercase() }
        SortMode.VIEWED -> filtered.sortedWith(
            compareByDescending<Recipe> { it.lastViewedAt }.thenByDescending { it.createdAt }
        )
    }
}

fun gridPadding(pad: PaddingValues, extraBottom: Dp = 24.dp): PaddingValues = PaddingValues(
    start = 16.dp,
    end = 16.dp,
    top = pad.calculateTopPadding() + 12.dp,
    bottom = pad.calculateBottomPadding() + extraBottom
)

fun LazyGridScope.fullWidth(content: @Composable () -> Unit) {
    item(span = { GridItemSpan(maxLineSpan) }) { content() }
}

fun LazyGridScope.recipeItems(list: List<Recipe>, onOpen: (Long) -> Unit, onFav: (Recipe) -> Unit) {
    items(list, key = { it.id }) { r ->
        RecipeCard(r, onClick = { onOpen(r.id) }, onFav = { onFav(r) })
    }
}

@Composable
fun SearchField(value: String, onChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        placeholder = { Text("Search recipes, ingredients…") },
        leadingIcon = { Text("🔍", fontSize = 18.sp) },
        trailingIcon = {
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }) { Text("✕", color = TextSecondary) }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Orange,
            cursorColor = Orange
        )
    )
}

@Composable
fun CategoryChips(names: List<String>, selected: String?, onSelect: (String?) -> Unit) {
    val colors = FilterChipDefaults.filterChipColors(
        selectedContainerColor = Orange,
        selectedLabelColor = Color.Black
    )
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            FilterChip(
                selected = selected == null,
                onClick = { onSelect(null) },
                label = { Text("All") },
                colors = colors
            )
        }
        items(names) { n ->
            FilterChip(
                selected = selected == n,
                onClick = { onSelect(if (selected == n) null else n) },
                label = { Text(n) },
                colors = colors
            )
        }
    }
}

@Composable
fun SortMenu(sort: SortMode, onSelect: (SortMode) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        TextButton(onClick = { open = true }) {
            Text("Sort: ${sort.label} ▾", color = Gold, fontSize = 13.sp)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            SortMode.entries.forEach { m ->
                DropdownMenuItem(
                    text = { Text(m.label) },
                    onClick = {
                        onSelect(m)
                        open = false
                    }
                )
            }
        }
    }
}

@Composable
fun EmptyState(emoji: String, title: String, subtitle: String) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderGrey),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(emoji, fontSize = 44.sp)
            Spacer(Modifier.height(8.dp))
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = TextSecondary, fontSize = 14.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun BottomNav(current: String, onTab: (String) -> Unit) {
    val tabs = listOf(
        Triple("home", "🏠", "Home"),
        Triple("categories", "🗂️", "Categories"),
        Triple("favourites", "❤️", "Favourites")
    )
    NavigationBar(containerColor = CardBg) {
        tabs.forEach { (route, icon, label) ->
            NavigationBarItem(
                selected = current == route,
                onClick = { onTab(route) },
                icon = { Text(icon, fontSize = 22.sp) },
                label = { Text(label) },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = CardBg2,
                    selectedTextColor = Orange,
                    unselectedTextColor = TextSecondary
                )
            )
        }
    }
}
