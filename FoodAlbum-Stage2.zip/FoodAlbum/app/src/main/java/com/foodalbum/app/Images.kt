package com.foodalbum.app

import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.util.LruCache
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private val bitmapCache = object : LruCache<String, ImageBitmap>((Runtime.getRuntime().maxMemory() / 8).toInt()) {
    override fun sizeOf(key: String, value: ImageBitmap): Int = value.asAndroidBitmap().byteCount
}

/**
 * Decodes a down-sampled copy of the image (the original file is never modified).
 * [minSide] = the smaller side of the decoded bitmap will be at least this many pixels (when the source allows it).
 */
fun decodeSampled(path: String, minSide: Int): ImageBitmap? {
    val key = "$path@$minSide"
    bitmapCache.get(key)?.let { return it }
    return try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= minSide && bounds.outHeight / (sample * 2) >= minSide) {
            sample *= 2
        }
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        var bmp = BitmapFactory.decodeFile(path, opts) ?: return null
        val degrees = try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        if (degrees != 0f) {
            val m = Matrix().apply { postRotate(degrees) }
            bmp = android.graphics.Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val img = bmp.asImageBitmap()
        bitmapCache.put(key, img)
        img
    } catch (e: Throwable) {
        null
    }
}

private sealed interface Loaded {
    data object Loading : Loaded
    data object Failed : Loaded
    class Ok(val bitmap: ImageBitmap) : Loaded
}

/**
 * Shows the recipe's OWN image from [path]. If [path] is null (or the file is gone) the neutral placeholder is shown.
 * Never falls back to another recipe's image or any stock image.
 */
@Composable
fun RecipeImage(
    path: String?,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    minSide: Int = 500,
    compactPlaceholder: Boolean = false,
    onAddImage: (() -> Unit)? = null
) {
    if (path == null) {
        ImagePlaceholder(modifier, compactPlaceholder, onAddImage)
        return
    }
    val state by produceState<Loaded>(Loaded.Loading, path, minSide) {
        val bmp = withContext(Dispatchers.IO) { decodeSampled(path, minSide) }
        value = if (bmp == null) Loaded.Failed else Loaded.Ok(bmp)
    }
    when (val s = state) {
        is Loaded.Ok -> Image(
            bitmap = s.bitmap,
            contentDescription = null,
            modifier = modifier,
            contentScale = contentScale
        )
        Loaded.Loading -> Box(modifier.background(CardBg2))
        Loaded.Failed -> ImagePlaceholder(modifier, compactPlaceholder, onAddImage)
    }
}

@Composable
fun ImagePlaceholder(
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    onAddImage: (() -> Unit)? = null
) {
    Box(
        modifier = modifier.background(Brush.verticalGradient(listOf(CardBg2, CardBg))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("📷", fontSize = if (compact) 30.sp else 46.sp)
            Text(
                "No image",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = if (compact) 12.sp else 14.sp
            )
            if (onAddImage != null) {
                Spacer(Modifier.height(10.dp))
                androidx.compose.material3.OutlinedButton(onClick = onAddImage) { Text("Add Image") }
            }
        }
    }
}
