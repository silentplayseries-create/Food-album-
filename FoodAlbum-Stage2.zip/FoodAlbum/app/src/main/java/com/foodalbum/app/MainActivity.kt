package com.foodalbum.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent {
            FoodAlbumTheme {
                App()
            }
        }
    }
}

@Composable
fun App(vm: AppViewModel = viewModel()) {
    val nav = rememberNavController()
    val idArg = listOf(navArgument("id") { type = NavType.LongType })

    val goTab: (String) -> Unit = { route ->
        nav.navigate(route) {
            popUpTo("home")
            launchSingleTop = true
        }
    }
    val openRecipe: (Long) -> Unit = { nav.navigate("detail/$it") }

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(vm = vm, onOpen = openRecipe, onAdd = { nav.navigate("edit/-1") }, onTab = goTab)
        }
        composable("categories") {
            CategoriesScreen(vm = vm, onOpenCategory = { nav.navigate("category/$it") }, onTab = goTab)
        }
        composable("favourites") {
            FavouritesScreen(vm = vm, onOpen = openRecipe, onTab = goTab)
        }
        composable("category/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: 0L
            CategoryRecipesScreen(vm = vm, catId = id, onBack = { nav.popBackStack() }, onOpen = openRecipe)
        }
        composable("edit/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: -1L
            EditScreen(
                vm = vm,
                id = id,
                onClose = { nav.popBackStack() },
                onSaved = { newId ->
                    nav.navigate("detail/$newId") { popUpTo("home") }
                }
            )
        }
        composable("detail/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: -1L
            DetailScreen(
                vm = vm,
                id = id,
                onBack = { nav.popBackStack() },
                onEdit = { nav.navigate("edit/$id") },
                onCook = { nav.navigate("cook/$id") },
                onViewImage = { nav.navigate("viewer/$id") }
            )
        }
        composable("viewer/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: -1L
            ImageViewerScreen(vm = vm, id = id, onClose = { nav.popBackStack() })
        }
        composable("cook/{id}", arguments = idArg) { entry ->
            val id = entry.arguments?.getLong("id") ?: -1L
            CookingScreen(vm = vm, id = id, onExit = { nav.popBackStack() })
        }
    }
}
