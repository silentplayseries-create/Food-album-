# Food Album — Stage 2

Kotlin + Jetpack Compose + Room. Fully offline, no login, no internet permission.

## STATUS: Stage 1 build passed on GitHub Actions. Stage 2 is NOT yet compiled or tested.

## Stage 2 mein naya kya hai
- Bottom navigation: Home, Categories, Favourites
- Categories screen: card + recipe count + thumbnail (us category ki apni image), create / rename / delete
  - delete par recipes "Other Recipes" mein move hoti hain (ya chaho to recipes bhi delete)
  - "Other Recipes" rename/delete nahi hoti (fallback category)
  - Edit screen mein bhi "+ New" se category ban sakti hai
- Category ya "All Recipes" kholne par us ki recipe list (search + sort ke saath)
- Favourites screen
- Home par search (name, category, ingredient, notes), category filter chips, sort (Recently Added / Oldest / A-Z / Recently Viewed)
- Full-screen image viewer: pinch zoom, double-tap zoom, Share, Save (jahan chaho), Change, Remove. Original file kabhi modify nahi hoti.
- Database version 1 -> 2 (migration). Purani recipes safe rehni chahiye, lekin ye bhi untested hai.

## Abhi bhi nahi hai (Stage 3)
Settings, light theme, backup/restore, camera photo, multiple images, crop.
