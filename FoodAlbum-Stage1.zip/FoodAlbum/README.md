# Food Album — Stage 1

Kotlin + Jetpack Compose + Room. Fully offline, no login, no internet permission.

## STATUS: NOT YET COMPILED OR TESTED
Ye code ek aise environment mein likha gaya jahan Android SDK/Gradle nahi tha.
Isliye abhi tak ek baar bhi build nahi hua. Pehli GitHub Actions build mein
compile errors aa sakte hain — log bhejoge to fix ho jayenge.

## Build (GitHub Actions)
1. Naya GitHub repo banao, is folder ki saari files (hidden `.github` folder ke saath) upload karo.
2. Repo > Actions > "Build APK" > Run workflow (ya `main` branch par push karo).
3. Build khatam hone par run page ke neeche **Artifacts > food-album-debug-apk** download karo.
4. Zip kholo, `app-debug.apk` install karo (Unknown sources allow karna padega).

## Stage 1 mein kya hai (implemented, untested)
- Own image: Photo Picker se pick -> app-private storage mein copy -> card/details/cooking mein wahi image
- Image nahi hai to neutral placeholder (kabhi stock/dusri recipe ki image nahi)
- Add / Edit recipe (ingredients + steps add, edit, delete, reorder)
- Ingredient checklist: tick, progress bar, "x of y", Check All, Reset, Room DB mein saved
- Cooking Mode: checklist, step navigation, "Recipe Completed!", screen awake, progress persist
- Home: 2-column recent grid, favourite heart, total count

## Stage 1 mein NAHI hai
Categories screen / custom categories, Favourites screen, search, sorting,
full-screen image viewer + zoom, camera photo, multiple images, crop, share,
light theme, settings, backup/restore.
