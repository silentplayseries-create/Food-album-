package com.foodalbum.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class IngDraft(
    val key: Long,
    val name: String = "",
    val quantity: String = "",
    val unit: String = "",
    val checked: Boolean = false
)

data class StepDraft(val key: Long, val text: String = "")

data class RecipeForm(
    val name: String,
    val category: String,
    val description: String,
    val prepTime: String,
    val cookTime: String,
    val servings: String,
    val difficulty: String,
    val notes: String,
    val imagePath: String?,
    val ingredients: List<IngDraft>,
    val steps: List<String>
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val imageDir = File(app.filesDir, "images").apply { mkdirs() }

    // null = still loading
    val recipes: StateFlow<List<Recipe>?> =
        dao.observeRecipes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    fun recipe(id: Long) = dao.observeRecipe(id)
    fun ingredients(id: Long) = dao.observeIngredients(id)
    fun steps(id: Long) = dao.observeSteps(id)

    suspend fun loadDraft(id: Long): Triple<Recipe, List<Ingredient>, List<Step>>? =
        withContext(Dispatchers.IO) {
            val r = dao.getRecipe(id)
            if (r == null) null else Triple(r, dao.getIngredients(id), dao.getSteps(id))
        }

    /** Copies the picked image into app-private storage. Returns the new file path, or null on failure. */
    suspend fun stageImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val f = File(imageDir, "${UUID.randomUUID()}.img")
            val input = getApplication<Application>().contentResolver.openInputStream(uri)
            if (input == null) {
                null
            } else {
                input.use { src -> f.outputStream().use { dst -> src.copyTo(dst) } }
                f.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveRecipe(id: Long, f: RecipeForm): Long = withContext(Dispatchers.IO) {
        val old = if (id > 0) dao.getRecipe(id) else null
        val base = old ?: Recipe(name = "", category = "")
        val recipe = base.copy(
            name = f.name.trim(),
            category = f.category,
            description = f.description.trim(),
            prepTime = f.prepTime.trim(),
            cookTime = f.cookTime.trim(),
            servings = f.servings.trim(),
            difficulty = f.difficulty,
            notes = f.notes.trim(),
            imagePath = f.imagePath
        )
        val ings = f.ingredients.filter { it.name.isNotBlank() }.mapIndexed { i, d ->
            Ingredient(
                recipeId = 0, position = i, name = d.name.trim(),
                quantity = d.quantity.trim(), unit = d.unit.trim(), checked = d.checked
            )
        }
        val steps = f.steps.filter { it.isNotBlank() }.mapIndexed { i, t ->
            Step(recipeId = 0, position = i, text = t.trim())
        }
        val newId = dao.saveRecipe(recipe, ings, steps)
        val oldPath = old?.imagePath
        if (oldPath != null && oldPath != f.imagePath) File(oldPath).delete()
        newId
    }

    fun replaceImage(id: Long, uri: Uri) {
        viewModelScope.launch {
            val p = stageImage(uri) ?: return@launch
            val old = dao.getRecipe(id)?.imagePath
            dao.setImage(id, p)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun removeImage(id: Long) {
        viewModelScope.launch {
            val old = dao.getRecipe(id)?.imagePath
            dao.setImage(id, null)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun deleteRecipe(id: Long, onDone: () -> Unit) {
        viewModelScope.launch {
            val old = dao.getRecipe(id)?.imagePath
            dao.deleteRecipe(id)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
            onDone()
        }
    }

    fun toggleFavourite(r: Recipe) {
        viewModelScope.launch { dao.setFavourite(r.id, !r.favourite) }
    }

    fun setChecked(ing: Ingredient, checked: Boolean) {
        viewModelScope.launch { dao.setChecked(ing.id, checked) }
    }

    fun checkAll(recipeId: Long) {
        viewModelScope.launch { dao.setAllChecked(recipeId, true) }
    }

    /** Resets only the ingredient ticks. The recipe itself is not touched. */
    fun resetChecklist(recipeId: Long) {
        viewModelScope.launch { dao.setAllChecked(recipeId, false) }
    }

    /** Resets ticks and goes back to step 1 (used by Cooking Mode). */
    fun resetCooking(recipeId: Long) {
        viewModelScope.launch {
            dao.setAllChecked(recipeId, false)
            dao.setCookStep(recipeId, 0)
        }
    }

    fun setCookStep(recipeId: Long, step: Int) {
        viewModelScope.launch { dao.setCookStep(recipeId, step.coerceAtLeast(0)) }
    }

    fun markViewed(id: Long) {
        viewModelScope.launch { dao.setViewed(id, System.currentTimeMillis()) }
    }
}
