package com.foodalbum.app

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

val DEFAULT_CATEGORIES = listOf(
    "Breakfast", "Lunch", "Dinner", "Snacks",
    "Sweets & Desserts", "Drinks", "Bakery", "Other Recipes"
)

@Entity(tableName = "recipes")
data class Recipe(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val category: String,
    val description: String = "",
    val prepTime: String = "",
    val cookTime: String = "",
    val servings: String = "",
    val difficulty: String = "",
    val notes: String = "",
    val imagePath: String? = null,
    val favourite: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val lastViewedAt: Long = 0,
    val cookStep: Int = 0
)

@Entity(
    tableName = "ingredients",
    foreignKeys = [ForeignKey(
        entity = Recipe::class,
        parentColumns = ["id"],
        childColumns = ["recipeId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("recipeId")]
)
data class Ingredient(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: Long,
    val position: Int,
    val name: String,
    val quantity: String,
    val unit: String,
    val checked: Boolean = false
)

@Entity(
    tableName = "steps",
    foreignKeys = [ForeignKey(
        entity = Recipe::class,
        parentColumns = ["id"],
        childColumns = ["recipeId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("recipeId")]
)
data class Step(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val recipeId: Long,
    val position: Int,
    val text: String
)

@Dao
abstract class RecipeDao {
    @Query("SELECT * FROM recipes ORDER BY createdAt DESC")
    abstract fun observeRecipes(): Flow<List<Recipe>>

    @Query("SELECT * FROM recipes WHERE id = :id")
    abstract fun observeRecipe(id: Long): Flow<Recipe?>

    @Query("SELECT * FROM recipes WHERE id = :id")
    abstract suspend fun getRecipe(id: Long): Recipe?

    @Query("SELECT * FROM ingredients WHERE recipeId = :id ORDER BY position")
    abstract fun observeIngredients(id: Long): Flow<List<Ingredient>>

    @Query("SELECT * FROM ingredients WHERE recipeId = :id ORDER BY position")
    abstract suspend fun getIngredients(id: Long): List<Ingredient>

    @Query("SELECT * FROM steps WHERE recipeId = :id ORDER BY position")
    abstract fun observeSteps(id: Long): Flow<List<Step>>

    @Query("SELECT * FROM steps WHERE recipeId = :id ORDER BY position")
    abstract suspend fun getSteps(id: Long): List<Step>

    @Insert
    abstract suspend fun insertRecipe(recipe: Recipe): Long

    @Update
    abstract suspend fun updateRecipe(recipe: Recipe)

    @Insert
    abstract suspend fun insertIngredients(list: List<Ingredient>)

    @Insert
    abstract suspend fun insertSteps(list: List<Step>)

    @Query("DELETE FROM ingredients WHERE recipeId = :id")
    abstract suspend fun clearIngredients(id: Long)

    @Query("DELETE FROM steps WHERE recipeId = :id")
    abstract suspend fun clearSteps(id: Long)

    @Query("DELETE FROM recipes WHERE id = :id")
    abstract suspend fun deleteRecipe(id: Long)

    @Query("UPDATE ingredients SET checked = :checked WHERE id = :id")
    abstract suspend fun setChecked(id: Long, checked: Boolean)

    @Query("UPDATE ingredients SET checked = :checked WHERE recipeId = :recipeId")
    abstract suspend fun setAllChecked(recipeId: Long, checked: Boolean)

    @Query("UPDATE recipes SET favourite = :fav WHERE id = :id")
    abstract suspend fun setFavourite(id: Long, fav: Boolean)

    @Query("UPDATE recipes SET imagePath = :path WHERE id = :id")
    abstract suspend fun setImage(id: Long, path: String?)

    @Query("UPDATE recipes SET cookStep = :step WHERE id = :id")
    abstract suspend fun setCookStep(id: Long, step: Int)

    @Query("UPDATE recipes SET lastViewedAt = :time WHERE id = :id")
    abstract suspend fun setViewed(id: Long, time: Long)

    @Transaction
    open suspend fun saveRecipe(recipe: Recipe, ings: List<Ingredient>, steps: List<Step>): Long {
        val id = if (recipe.id == 0L) {
            insertRecipe(recipe)
        } else {
            updateRecipe(recipe)
            recipe.id
        }
        clearIngredients(id)
        clearSteps(id)
        insertIngredients(ings.map { it.copy(id = 0, recipeId = id) })
        insertSteps(steps.map { it.copy(id = 0, recipeId = id) })
        return id
    }
}

@Database(entities = [Recipe::class, Ingredient::class, Step::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): RecipeDao

    companion object {
        @Volatile
        private var instance: AppDatabase? = null

        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "food_album.db"
            ).build().also { instance = it }
        }
    }
}
