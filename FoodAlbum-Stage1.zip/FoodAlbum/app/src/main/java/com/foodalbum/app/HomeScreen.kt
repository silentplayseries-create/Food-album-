package com.foodalbum.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(vm: AppViewModel, onOpen: (Long) -> Unit, onAdd: () -> Unit) {
    val recipes by vm.recipes.collectAsState()
    val list = recipes ?: emptyList()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, containerColor = Orange, contentColor = Color.Black) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add Recipe", fontWeight = FontWeight.Bold)
            }
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = pad.calculateTopPadding() + 12.dp,
                bottom = pad.calculateBottomPadding() + 96.dp
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                HomeHeader(count = list.size)
            }
            if (recipes != null && list.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = CardBg),
                        border = BorderStroke(1.dp, BorderGrey),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(28.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("🍽️", fontSize = 44.sp)
                            Spacer(Modifier.size(8.dp))
                            Text("No recipes yet", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(
                                "Tap “Add Recipe” to save your first one.",
                                color = TextSecondary,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }
            if (list.isNotEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Text("Recently Added", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Gold)
                }
                items(list, key = { it.id }) { r ->
                    RecipeCard(r, onClick = { onOpen(r.id) }, onFav = { vm.toggleFavourite(r) })
                }
            }
        }
    }
}

@Composable
private fun HomeHeader(count: Int) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Orange),
                contentAlignment = Alignment.Center
            ) { Text("🍳", fontSize = 24.sp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Food Album", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Save • Organize • Cook • Enjoy", color = Gold, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.size(20.dp))
        Text("Your Recipe Collection", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            if (count == 1) "1 recipe saved" else "$count recipes saved",
            color = TextSecondary,
            fontSize = 14.sp
        )
    }
}

@Composable
fun RecipeCard(r: Recipe, onClick: () -> Unit, onFav: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        modifier = Modifier
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderGrey)
    ) {
        Box {
            RecipeImage(
                path = r.imagePath,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.8f),
                contentScale = ContentScale.Crop,
                minSide = 500,
                compactPlaceholder = true
            )
            IconButton(
                onClick = onFav,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(40.dp)
                    .background(Color.Black.copy(alpha = 0.45f), CircleShape)
            ) {
                Icon(
                    Icons.Default.Favorite,
                    contentDescription = "Favourite",
                    tint = if (r.favourite) Orange else Color.White.copy(alpha = 0.8f)
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                r.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(r.category, color = Gold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}
