# Food Album — Stage 3 (Scan Recipe / OCR) — parser accuracy fix

Kotlin + Jetpack Compose + Room. Offline. No login, no analytics, no API keys.

## STATUS
Stage 1 and 2 build on GitHub Actions and run on the phone.
Stage 3 (this version) is NOT yet compiled on GitHub Actions or tested on a phone.

## What changed in this fix
- OCR layer now keeps line + word bounding boxes (ML Kit) instead of flattening everything to plain strings.
- Parser rebuilt: splits lines that run across two columns, restores reading order of multi-column posters,
  joins "name | quantity" table rows, fuzzy section headings, evidence-based classification
  (a line is only an ingredient / step when the text supports it), "Unclassified Text" for the rest.
- Review screen: "Unclassified Text" panel (move each line to Ingredient / Step / Note, or remove),
  "Original Scanned Text" always available.
- No database change (still v3).

## Tests
app/src/test/.../RecipeParserTest.kt  (JVM unit tests).  Run: gradle testDebugUnitTest
