# Food Album — Stage 3 (Scan Recipe / OCR)

Kotlin + Jetpack Compose + Room. Offline. No login, no analytics, no API keys.

## STATUS
Stage 1 and 2 build on GitHub Actions and run on the phone.
Stage 3 is NOT yet compiled or tested — the GitHub Actions build is the first real check.

## Stage 3
- Home: "Scan Recipe" button -> Choose Recipe Image (gallery) / Take Photo (phone's camera app, no CAMERA permission)
- On-device OCR with Google ML Kit (bundled models, no download, nothing uploaded): English/Latin first,
  Hindi (Devanagari) as automatic fallback or via "Read as Hindi" on the review screen
- Review Recipe screen = the existing editor, pre-filled: every field editable, original OCR text viewable,
  Rescan Image, Cancel. Nothing is saved until "Save Recipe".
- Ingredients are saved as separate rows (name / quantity / unit) -> separate checkboxes in Cooking Mode
- New recipe fields: Total time, Original OCR text (shown on the details page)
- Database v2 -> v3 (migration keeps all existing data)

## Dependencies added
com.google.mlkit:text-recognition:16.0.0 and text-recognition-devanagari:16.0.0 (APK grows by roughly 10-20 MB).
