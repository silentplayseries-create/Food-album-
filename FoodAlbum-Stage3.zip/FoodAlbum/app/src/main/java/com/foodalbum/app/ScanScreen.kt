package com.foodalbum.app

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ScanScreen(vm: AppViewModel, onBack: () -> Unit, onScanned: () -> Unit, onManual: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val cats by vm.categories.collectAsState()

    var working by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var camFile by remember { mutableStateOf<File?>(null) }

    fun startScan(uri: Uri, temp: File?) {
        error = null
        working = true
        job = scope.launch {
            val path = vm.stageImage(uri)
            temp?.delete()
            if (path == null) {
                error = "That image couldn't be opened. Please try another one."
                working = false
                return@launch
            }
            try {
                var script = OcrScript.LATIN
                var res = runOcr(path, script)
                if (res.lines.isEmpty()) {
                    // Nothing in English/Latin script: try the Hindi (Devanagari) reader before giving up.
                    script = OcrScript.DEVANAGARI
                    res = runOcr(path, script)
                }
                if (res.lines.isEmpty()) {
                    File(path).delete()
                    error = "No readable text was found. Try a sharper, well-lit, straight-on photo — or enter the recipe manually."
                    working = false
                    return@launch
                }
                val parsed = parseRecipe(res.lines)
                val cat = guessCategory(res.lines.take(4).joinToString(" ") { it.text }, cats.map { it.name })
                vm.setScanDraft(ScanDraft(path, res.text, script, parsed, cat))
                working = false
                onScanned()
            } catch (e: CancellationException) {
                File(path).delete()
                throw e
            } catch (e: Exception) {
                File(path).delete()
                error = "Couldn't read this image. Please try again or enter the recipe manually."
                working = false
            }
        }
    }

    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) startScan(uri, null)
    }

    // Uses the phone's own camera app, so the CAMERA permission is not needed.
    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = camFile
        if (ok && f != null) {
            startScan(Uri.fromFile(f), f)
        } else {
            f?.delete()
        }
    }

    fun launchCamera() {
        try {
            val dir = File(ctx.cacheDir, "camera").apply { mkdirs() }
            val f = File(dir, "capture_${System.currentTimeMillis()}.jpg")
            camFile = f
            camera.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f))
        } catch (e: Exception) {
            error = "No camera app is available on this phone. Choose an image from the gallery instead."
        }
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { AppTopBar("Scan Recipe", onBack = onBack) }
    ) { pad ->
        Column(
            modifier = Modifier
                .padding(pad)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CardBg),
                border = BorderStroke(1.dp, BorderGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("📷", fontSize = 44.sp)
                    Text("Scan Recipe", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        "Pick a photo of a recipe poster. The text is read on your phone — " +
                            "nothing is uploaded. You can check and correct everything before saving.",
                        color = TextSecondary,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }

            if (working) {
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg2),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        CircularProgressIndicator(color = Orange)
                        Text("Reading Recipe...", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        TextButton(onClick = {
                            job?.cancel()
                            working = false
                        }) { Text("Cancel", color = TextSecondary) }
                    }
                }
            } else {
                Button(
                    onClick = {
                        gallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                ) { Text("Choose Recipe Image", fontSize = 17.sp, fontWeight = FontWeight.Bold) }

                OutlinedButton(
                    onClick = { launchCamera() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp)
                ) { Text("Take Photo", fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }

            error?.let { msg ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = CardBg),
                    border = BorderStroke(1.dp, Danger),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(msg, color = Color.White, fontSize = 15.sp)
                        Text("Choose another image above to try again.", color = TextSecondary, fontSize = 13.sp)
                    }
                }
            }

            Spacer(Modifier.size(4.dp))
            TextButton(onClick = onManual, modifier = Modifier.fillMaxWidth()) {
                Text("Enter recipe manually instead", color = Gold)
            }
        }
    }
}
