package com.foodalbum.app

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class IngDraft(
    val key: Long,
    val name: String = "",
    val quantity: String = "",
    val unit: String = "",
    val checked: Boolean = false
)

data class StepDraft(val key: Long, val text: String = "")

data class RecipeForm(
    val name: String,
    val category: String,
    val description: String,
    val prepTime: String,
    val cookTime: String,
    val servings: String,
    val difficulty: String,
    val notes: String,
    val imagePath: String?,
    val ingredients: List<IngDraft>,
    val steps: List<String>,
    val totalTime: String = "",
    val ocrText: String = ""
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val imageDir = File(app.filesDir, "images").apply { mkdirs() }

    // null = still loading
    val recipes: StateFlow<List<Recipe>?> =
        dao.observeRecipes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), null)

    val categories: StateFlow<List<Category>> =
        dao.observeCategories().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val ingredientNames: StateFlow<List<IngName>> =
        dao.observeIngredientNames().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // First run (or first run after the Stage 2 update): create the default categories.
        viewModelScope.launch {
            if (dao.categoryCount() == 0) {
                dao.insertCategories(DEFAULT_CATEGORIES.mapIndexed { i, n -> Category(name = n, position = i) })
            }
        }
    }

    // ---- Scan Recipe (Stage 3): the draft lives here until the user saves or cancels ----
    private var scanDraft: ScanDraft? = null

    fun setScanDraft(d: ScanDraft) {
        scanDraft = d
    }

    fun takeScanDraft(): ScanDraft? {
        val d = scanDraft
        scanDraft = null
        return d
    }

    suspend fun recipeNameExists(name: String): Boolean = dao.countByName(name.trim()) > 0

    fun recipe(id: Long) = dao.observeRecipe(id)
    fun ingredients(id: Long) = dao.observeIngredients(id)
    fun steps(id: Long) = dao.observeSteps(id)

    suspend fun loadDraft(id: Long): Triple<Recipe, List<Ingredient>, List<Step>>? =
        withContext(Dispatchers.IO) {
            val r = dao.getRecipe(id)
            if (r == null) null else Triple(r, dao.getIngredients(id), dao.getSteps(id))
        }

    /** Copies the picked image into app-private storage. Returns the new file path, or null on failure. */
    suspend fun stageImage(uri: Uri): String? = withContext(Dispatchers.IO) {
        try {
            val f = File(imageDir, "${UUID.randomUUID()}.img")
            val input = getApplication<Application>().contentResolver.openInputStream(uri)
            if (input == null) {
                null
            } else {
                input.use { src -> f.outputStream().use { dst -> src.copyTo(dst) } }
                f.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun saveRecipe(id: Long, f: RecipeForm): Long = withContext(Dispatchers.IO) {
        val old = if (id > 0) dao.getRecipe(id) else null
        val base = old ?: Recipe(name = "", category = "")
        val recipe = base.copy(
            name = f.name.trim(),
            category = f.category,
            description = f.description.trim(),
            prepTime = f.prepTime.trim(),
            cookTime = f.cookTime.trim(),
            servings = f.servings.trim(),
            difficulty = f.difficulty,
            notes = f.notes.trim(),
            totalTime = f.totalTime.trim(),
            ocrText = f.ocrText,
            imagePath = f.imagePath
        )
        val ings = f.ingredients.filter { it.name.isNotBlank() }.mapIndexed { i, d ->
            Ingredient(
                recipeId = 0, position = i, name = d.name.trim(),
                quantity = d.quantity.trim(), unit = d.unit.trim(), checked = d.checked
            )
        }
        val steps = f.steps.filter { it.isNotBlank() }.mapIndexed { i, t ->
            Step(recipeId = 0, position = i, text = t.trim())
        }
        val newId = dao.saveRecipe(recipe, ings, steps)
        val oldPath = old?.imagePath
        if (oldPath != null && oldPath != f.imagePath) File(oldPath).delete()
        newId
    }

    fun replaceImage(id: Long, uri: Uri) {
        viewModelScope.launch {
            val p = stageImage(uri) ?: return@launch
            val old = dao.getRecipe(id)?.imagePath
            dao.setImage(id, p)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun removeImage(id: Long) {
        viewModelScope.launch {
            val old = dao.getRecipe(id)?.imagePath
            dao.setImage(id, null)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
        }
    }

    fun deleteRecipe(id: Long, onDone: () -> Unit) {
        viewModelScope.launch {
            val old = dao.getRecipe(id)?.imagePath
            dao.deleteRecipe(id)
            if (old != null) withContext(Dispatchers.IO) { File(old).delete() }
            onDone()
        }
    }

    fun toggleFavourite(r: Recipe) {
        viewModelScope.launch { dao.setFavourite(r.id, !r.favourite) }
    }

    fun setChecked(ing: Ingredient, checked: Boolean) {
        viewModelScope.launch { dao.setChecked(ing.id, checked) }
    }

    fun checkAll(recipeId: Long) {
        viewModelScope.launch { dao.setAllChecked(recipeId, true) }
    }

    /** Resets only the ingredient ticks. The recipe itself is not touched. */
    fun resetChecklist(recipeId: Long) {
        viewModelScope.launch { dao.setAllChecked(recipeId, false) }
    }

    /** Resets ticks and goes back to step 1 (used by Cooking Mode). */
    fun resetCooking(recipeId: Long) {
        viewModelScope.launch {
            dao.setAllChecked(recipeId, false)
            dao.setCookStep(recipeId, 0)
        }
    }

    fun setCookStep(recipeId: Long, step: Int) {
        viewModelScope.launch { dao.setCookStep(recipeId, step.coerceAtLeast(0)) }
    }

    /** Returns an error message, or null on success. */
    suspend fun addCategory(name: String): String? {
        val n = name.trim()
        if (n.isEmpty()) return "Enter a category name"
        val all = dao.getCategories()
        if (all.any { it.name.equals(n, ignoreCase = true) }) return "That category already exists"
        dao.insertCategory(Category(name = n, position = (all.maxOfOrNull { it.position } ?: -1) + 1))
        return null
    }

    /** Returns an error message, or null on success. Recipes in the category follow the new name. */
    suspend fun renameCategory(cat: Category, newName: String): String? {
        val n = newName.trim()
        if (n.isEmpty()) return "Enter a category name"
        if (cat.name == OTHER_CATEGORY) return "This category can't be renamed"
        val all = dao.getCategories()
        if (all.any { it.id != cat.id && it.name.equals(n, ignoreCase = true) }) return "That category already exists"
        dao.renameCategory(cat.id, cat.name, n)
        return null
    }

    /** Recipes are moved to "Other Recipes", or deleted too if [deleteRecipes] is true. */
    suspend fun deleteCategory(cat: Category, deleteRecipes: Boolean) {
        if (cat.name == OTHER_CATEGORY) return
        if (deleteRecipes) {
            val paths = dao.getRecipesIn(cat.name).mapNotNull { it.imagePath }
            dao.deleteRecipesIn(cat.name)
            withContext(Dispatchers.IO) { paths.forEach { File(it).delete() } }
        } else {
            dao.moveRecipes(cat.name, OTHER_CATEGORY)
        }
        dao.deleteCategoryRow(cat.id)
    }

    fun markViewed(id: Long) {
        viewModelScope.launch { dao.setViewed(id, System.currentTimeMillis()) }
    }
}
