package com.foodalbum.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class OcrScript { LATIN, DEVANAGARI }

/** [text] is exactly the recognised lines joined by newlines — the source of truth for the user. */
class OcrResult(val text: String, val lines: List<String>)

/** Everything the Review screen needs. Kept in the ViewModel until the user saves or cancels. */
data class ScanDraft(
    val imagePath: String,
    val ocrText: String,
    val script: OcrScript,
    val parsed: ParsedRecipe,
    val category: String
)

/** Decodes a down-sampled bitmap (longest side <= maxSide) with EXIF rotation applied. Original file untouched. */
private fun decodeForOcr(path: String, maxSide: Int = 3200): Bitmap? {
    try {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return null
        val degrees = try {
            when (ExifInterface(path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
        } catch (e: Exception) {
            0f
        }
        if (degrees == 0f) return decoded
        val m = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(decoded, 0, 0, decoded.width, decoded.height, m, true)
    } catch (e: Throwable) {
        return null
    }
}

private suspend fun TextRecognizer.awaitText(image: InputImage): Text =
    suspendCancellableCoroutine { cont ->
        process(image)
            .addOnSuccessListener { cont.resume(it) }
            .addOnFailureListener { cont.resumeWithException(it) }
    }

/**
 * Real on-device OCR (Google ML Kit, bundled models — no network, nothing is uploaded).
 * Runs off the main thread. Throws if the image cannot be opened or the recogniser fails.
 */
suspend fun runOcr(path: String, script: OcrScript): OcrResult = withContext(Dispatchers.Default) {
    val bmp = decodeForOcr(path) ?: throw IllegalStateException("Could not open the image")
    val recognizer: TextRecognizer = when (script) {
        OcrScript.LATIN -> TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        OcrScript.DEVANAGARI -> TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    }
    try {
        val result = recognizer.awaitText(InputImage.fromBitmap(bmp, 0))
        val lines = result.textBlocks
            .flatMap { block -> block.lines.map { it.text.trim() } }
            .filter { it.isNotEmpty() }
        OcrResult(lines.joinToString("\n"), lines)
    } finally {
        recognizer.close()
    }
}
