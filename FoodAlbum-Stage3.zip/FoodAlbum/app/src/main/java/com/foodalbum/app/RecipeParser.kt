package com.foodalbum.app

/**
 * OCR text -> recipe fields. Pure Kotlin (no Android classes) so it can be unit tested on the JVM.
 *
 * Pipeline:  OCR lines (+ boxes)  ->  split lines that span two columns  ->  reading order (columns)
 *            ->  join "name | quantity" table rows  ->  normalise  ->  section / metadata / evidence based classification.
 *
 * Nothing is invented: fields that cannot be supported by the text stay blank, and lines the parser is not
 * sure about are returned in [ParsedRecipe.unclassified] for the user to place by hand.
 */

class OcrWord(val text: String, val l: Int, val t: Int, val r: Int, val b: Int)

/** One recognised line. Coordinates are -1 when the OCR engine gave no geometry. */
class OcrLine(
    val text: String,
    val l: Int = -1,
    val t: Int = -1,
    val r: Int = -1,
    val b: Int = -1,
    val block: Int = 0,
    val words: List<OcrWord> = emptyList()
) {
    val hasBox: Boolean get() = r > l && b > t
    val h: Int get() = b - t
    val cy: Double get() = (t + b) / 2.0
}

data class ParsedIngredient(val name: String, val quantity: String, val unit: String)

data class ParsedRecipe(
    val name: String,
    val ingredients: List<ParsedIngredient>,
    val steps: List<String>,
    val prepTime: String,
    val cookTime: String,
    val totalTime: String,
    val servings: String,
    val notes: String,
    val unclassified: List<String>
)

// ------------------------------------------------------------------------------------------ constants

private const val FR = "½¼¾⅓⅔"
private const val NUM = """(?:\d+\s+\d+/\d+|\d+/\d+|\d+(?:[.,]\d+)?[$FR]?|[$FR])"""
private const val RANGE = NUM + """(?:\s*(?:-|–|—|to)\s*""" + NUM + """)?"""
private const val APPROX = "(?:about|approximately|approx\\.?|around|~)"

private val WS_RE = Regex("\\s+")

private fun words(vararg blocks: String): Set<String> =
    blocks.joinToString(" ").split(WS_RE).filter { it.isNotEmpty() }.toSet()

private val UNITS: Set<String> = words(
    "g gm gms gram grams kg kgs kilo kilos kilogram kilograms mg ml l ltr litre litres liter liters cup cups",
    "tbsp tbs tbl tblsp tablespoon tablespoons tsp tsps teaspoon teaspoons oz ounce ounces lb lbs pound pounds",
    "pinch pinches piece pieces pcs pc clove cloves slice slices bunch bunches handful sprig sprigs stick sticks",
    "inch inches nos can cans packet packets glass glasses dash drops strands bottle pod pods leaf leaves knob",
    "ग्राम किलो चम्मच कप लीटर मिली चुटकी"
)

private val PHRASES: List<String> = listOf(
    "to taste", "as required", "as needed", "as per taste", "as per requirement", "as desired",
    "a pinch", "a handful", "a few", "pinch", "handful", "few", "some",
    "स्वादानुसार", "आवश्यकतानुसार"
).sortedByDescending { it.length }

private val DESCR: Set<String> = words(
    "small medium large big ripe chopped sliced diced grated crushed minced peeled mashed"
)
private val ADV: Set<String> = words("finely roughly coarsely thinly thickly freshly lightly")

private val HEADERS: Map<String, List<String>> = linkedMapOf(
    "ing" to listOf(
        "ingredients", "ingredient", "ingredients list", "ingredients required", "for ingredients",
        "main ingredients", "what you need", "you will need", "you ll need", "things you need",
        "सामग्री", "आवश्यक सामग्री"
    ),
    "step" to listOf(
        "method", "instructions", "instruction", "preparation", "preparation method", "cooking method",
        "cooking instructions", "directions", "direction", "steps", "how to make", "how to cook", "procedure",
        "recipe method", "विधि", "बनाने की विधि", "बनाने का तरीका", "तरीका"
    ),
    "note" to listOf(
        "notes", "note", "tips", "tip", "chef s tip", "chefs tip", "chef tip", "pro tip", "नोट", "टिप्स"
    )
)

private val GROUP_WORDS: Set<String> = words(
    "gravy marinade marination masala paste garnish garnishing topping toppings dough filling stuffing sauce",
    "batter tadka tempering base syrup coating dressing seasoning spices"
)

private val VERBS: Set<String> = words(
    "heat add mix cook stir fry saute sauté boil simmer bake grind blend chop cut peel wash soak marinate cover keep",
    "serve garnish pour transfer remove drain knead roll fold whisk beat preheat grease grate mash squeeze sprinkle",
    "season roast steam toss cool let allow bring reduce taste check take put place turn flip press spread dip coat",
    "refrigerate chill freeze drizzle combine prepare make switch wait finally next then now once after when",
    "meanwhile open close arrange brush temper rinse reserve stuff shape divide slice dice mince crush break scrape",
    "strain sieve sift lightly gently slowly deep-fry shallow-fry pressure-cook roast-dry dry-roast"
)

private val HI_END: List<String> = listOf(
    "करें", "डालें", "मिलाएं", "मिलाएँ", "पकाएं", "पकाएँ", "भूनें", "उबालें", "रखें", "निकालें", "डालिए",
    "कीजिए", "तलें", "छानें", "गूंथें", "बेलें", "काटें", "पीसें", "मिलाइए", "पकाइए", "भूनिए", "लें", "दें",
    "जाएं", "जाएँ"
)

private const val LABELS =
    "(?:prep(?:aration)?\\s*time|cook(?:ing)?\\s*time|total\\s*time|ready\\s*in|serves|servings?(?:\\s*size)?|yields?|" +
        "तैयारी का समय|पकाने का समय|बनाने का समय|कुल समय|कितने लोगों के लिए|लोगों के लिए|prep|cook)"

private val LABEL_PHRASES: Map<String, List<String>> = linkedMapOf(
    "prep" to listOf("prep time", "preparation time"),
    "cook" to listOf("cook time", "cooking time"),
    "total" to listOf("total time", "ready in"),
    "serv" to listOf("serves", "servings", "serving size", "yield", "portions")
)

private val IC = RegexOption.IGNORE_CASE
private val LABEL_RE = Regex(LABELS + "(?:\\s*[:\\-–—]\\s*|\\s+(?=\\d)|\\s*$)", IC)
private val BARE_LABEL_RE = Regex("^(prep|cook)\\s*[:\\-–—\\s]*$", IC)
private val SERV_ONLY_RE = Regex(
    "^(?:for\\s+|serves?\\s+)?(\\d+(?:\\s*(?:-|–|to)\\s*\\d+)?\\s*(?:servings?|people|persons|portions|pax))\\s*$", IC
)
private val DAMAGED_LABEL_RE = Regex("^\\s*([^:\\-–—|\\d]{4,28}?)\\s*[:\\-–—]\\s*(\\S.*)$")

private val PAREN_RE = Regex("\\([^)]*\\)")
private val PAREN_CAP_RE = Regex("\\(([^)]*)\\)")
private val PAREN_STRIP_RE = Regex("\\s*\\([^)]*\\)")
private val FOR_RE = Regex("^(?:for|to make|to prepare)\\s+(?:the\\s+)?(\\S.*)$")
private val OF_RE = Regex("^of\\s+", IC)

private val BULLET_RE = Regex("^[\\s•*·▪■□☐☑✓✔>\\-–—]+")
private val NUMBERING_RE = Regex("^\\d+\\s*[.)]\\s+(?=\\D)")
private val STEP_NUM_RE = Regex("^\\s*(?:step\\s*\\d+|\\d+\\s*[.)])\\s*", IC)
private val STEP_STRIP_RE = Regex("^(?:step\\s*\\d+\\s*[:.\\-–)]?\\s*|\\d+\\s*[.)]\\s+|[•*\\-–·▪]\\s*)", IC)

private val QTY_START_RE = Regex("^(" + RANGE + ")\\s*(.*)$")
private val APPROX_START_RE = Regex("^(" + APPROX + ")(?=[\\s\\d])\\s*(.*)$", IC)
private val APPROX_END_RE = Regex("\\s+(" + APPROX + ")$", IC)
private val FULL_RANGE_RE = Regex(RANGE)
private val SEP1_RE = Regex("^(.*?)\\s+[-–—]+\\s+(.+)$")
private val SEP2_RE = Regex("^(.*?)\\s*:\\s*(.+)$")
private val SEP3_RE = Regex("^(.*?)\\s+[-–—]\\s*(\\d.*)$")
private val SEP_LIST = listOf(SEP1_RE, SEP2_RE, SEP3_RE)
private val TRAIL_RE = Regex("^(.*\\S)\\s+(" + RANGE + ")(?:\\s*([A-Za-z]+)\\.?)?\\s*$")
private val PAREN_QTY_RE = Regex(
    "^(.*\\S)\\s*\\(\\s*(" + RANGE + ")\\s*([A-Za-z\u0900-\u097F]+)?\\s*\\)\\s*$"
)

private val TIME_WORD_RE = Regex(
    "^(?:minutes?|mins?|min\\.|hours?|hrs?|hr|seconds?|secs?|days?|whistles?|मिनट|घंटे?|घण्टे?)\\b", IC
)
private val TIME_PHRASE_RE = Regex(
    "^\\(?(?:for\\s+)?\\d+(?:\\s*(?:-|–|to)\\s*\\d+)?\\s*" +
        "(?:minutes?|mins?|min\\.|hours?|hrs?|hr|seconds?|secs?|days?|whistles?|मिनट|घंटे?)\\b", IC
)

private val LEADER_RE = Regex("\\.{3,}|…+|_{2,}|·{2,}|-{3,}")
private val SLASH_RE = Regex("(?<=\\d)\\s*/\\s*(?=\\d)")
private val GLUE_RE = Regex("(?<=[A-Za-z])(?=\\d+\\s*(?:g|gm|kg|ml|l|cups?|tsp|tbsp)\\b)")
private val LONE_L_RE = Regex(
    "(?<![A-Za-z])[lI|](?=\\s*(?:g|gm|kg|ml|cup|cups|tsp|tbsp|tablespoons?|teaspoons?)\\b)"
)
private val O_DIGITS_RE = Regex("(?<![A-Za-z])[0-9Oo]{2,}(?![A-Za-z])")

private val JUNK_RE = Regex(
    "(www\\.|https?://|\\.com\\b|@\\w{3,}|\\b(?:subscribe|follow us|follow me|like\\s*&?\\s*share|youtube|" +
        "instagram|facebook|whatsapp|click here|visit us|order now)\\b|©|\\+?\\d[\\d\\s\\-]{9,})", IC
)
private val ORPHAN_NUM_RE = Regex("\\d+\\s*[.)]")
private val LONE_NUM_RE = Regex("\\d{1,2}")

private const val HEADER_PUNCT = ".,:;|•*-–—_()[]{}!?\"“”‘’~`/\\"
private val TRIM_NAME = charArrayOf(' ', ',', ';', '-', '–', '—')
private val TRIM_VAL = charArrayOf(' ', '|', ',', ';', '•', '·', '-', '–', '—', '/')

// ------------------------------------------------------------------------------------------ small helpers

private fun normHeader(s: String): String {
    val sb = StringBuilder()
    for (c in s.replace("'", " ")) sb.append(if (HEADER_PUNCT.indexOf(c) >= 0) ' ' else c)
    return sb.toString().lowercase().split(WS_RE).filter { it.isNotEmpty() }.joinToString(" ")
}

private fun lev(a: String, b: String): Int {
    if (a == b) return 0
    var prev = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
        val cur = IntArray(b.length + 1)
        cur[0] = i
        for (j in 1..b.length) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        }
        prev = cur
    }
    return prev[b.length]
}

private fun fuzzyEq(a: String, b: String): Boolean {
    if (a == b) return true
    val n = maxOf(a.length, b.length)
    if (n < 6) return false
    return lev(a, b) <= (if (n < 11) 1 else 2)
}

private fun tokens(s: String): List<String> =
    s.split(WS_RE).filter { t -> t.isNotEmpty() && t.trim('.', ',', ';', ':', '!', '?', '(', ')', '[', ']', '-', '–', '—').isNotEmpty() }

private fun endsWithStop(s: String, stops: String): Boolean {
    val c = s.trimEnd().lastOrNull() ?: return true   // same as the reference: an empty string counts as "ends with"
    return stops.indexOf(c) >= 0
}

private fun normalize(line: String): String {
    var s = line.replace('\u00a0', ' ').replace('‒', '–').trim()
    s = LEADER_RE.replace(s, " - ")
    s = SLASH_RE.replace(s, "/")
    s = GLUE_RE.replace(s, " ")
    s = LONE_L_RE.replace(s, "1")
    s = O_DIGITS_RE.replace(s) { m ->
        val w = m.value
        if (w.any { it.isDigit() }) w.replace('O', '0').replace('o', '0') else w
    }
    return s.split(WS_RE).filter { it.isNotEmpty() }.joinToString(" ")
}

private fun stripBullet(s: String): String = BULLET_RE.replace(s, "")

private fun capFirst(s: String): String = s.replaceFirstChar { it.uppercase() }

// ------------------------------------------------------------------------------------------ headers / fields

/** (kind, text after the colon, ingredient group label) or null. kind = ing | step | note */
private fun headerOf(line: String, section: String? = null): Triple<String, String, String>? {
    val t = PAREN_RE.replace(line, " ").trim()
    val idx = t.indexOf(':')
    val cands = mutableListOf(Pair(t, ""))
    if (idx >= 0) cands.add(Pair(t.substring(0, idx), t.substring(idx + 1).trim()))
    for ((cand, rest) in cands) {
        val n = normHeader(cand)
        if (n.isEmpty()) continue
        val nWords = n.split(" ").size
        if (nWords > 5) continue
        for ((kind, lst) in HEADERS) {
            for (h in lst) if (n == h || fuzzyEq(n, h)) return Triple(kind, rest, "")
        }
        val m = FOR_RE.find(n)
        if (m != null && n.none { it.isDigit() } && nWords <= 4 && rest.isEmpty()) {
            return Triple("ing", rest, m.groupValues[1])
        }
        if (n in GROUP_WORDS && section != "step" && (cand.trim().endsWith(":") || nWords == 1) && rest.isEmpty()) {
            return Triple("ing", rest, n)
        }
    }
    return null
}

private fun kindOf(label: String): String {
    val l = label.lowercase()
    return when {
        l.contains("prep") || l.contains("तैयारी") -> "prep"
        l.contains("total") || l.contains("ready") || l.contains("कुल") -> "total"
        l.contains("cook") || l.contains("पकाने") || l.contains("बनाने का समय") -> "cook"
        else -> "serv"
    }
}

/** Metadata. Handles "Cooking Time: 30 min" and "Prep: 10 min | Cook: 20 min | Serves 4". */
private fun fieldsOf(line: String): List<Pair<String, String>>? {
    val m0 = SERV_ONLY_RE.find(line.trim())
    if (m0 != null) return listOf(Pair("serv", m0.groupValues[1].trim()))
    val ms = LABEL_RE.findAll(line).toList()
    if (ms.isNotEmpty() && ms[0].range.first <= 3) {
        val out = mutableListOf<Pair<String, String>>()
        for ((i, m) in ms.withIndex()) {
            val end = if (i + 1 < ms.size) ms[i + 1].range.first else line.length
            val value = line.substring(m.range.last + 1, end).trim(*TRIM_VAL)
            if (BARE_LABEL_RE.matches(m.value)) {
                // a bare "Prep:" / "Cook:" only counts with a colon and a number after it
                if (!m.value.contains(':') || value.none { it.isDigit() }) return null
            }
            out.add(Pair(kindOf(m.value), value))
        }
        return out
    }
    val d = DAMAGED_LABEL_RE.find(line)
    if (d != null && d.groupValues[2].any { it.isDigit() }) {
        val n = normHeader(d.groupValues[1])
        for ((k, lst) in LABEL_PHRASES) {
            if (lst.any { fuzzyEq(n, it) }) return listOf(Pair(k, d.groupValues[2].trim(' ', '|', ',', ';')))
        }
    }
    return null
}

// ------------------------------------------------------------------------------------------ ingredients

/** (quantity, unit, leftover) or null when the text does not start with a quantity. */
private fun parseQty(text: String): Triple<String, String, String>? {
    var t = text.trim()
    var pre = ""
    val am = APPROX_START_RE.find(t)
    if (am != null && am.groupValues[2].isNotEmpty()) {
        pre = am.groupValues[1].trimEnd('.') + " "
        t = am.groupValues[2]
    }
    val low = t.lowercase()
    for (p in PHRASES) {
        if (low.startsWith(p) && (t.length == p.length || !t[p.length].isLetterOrDigit())) {
            return Triple(p, "", t.substring(p.length).trim(*TRIM_NAME))
        }
    }
    val m = QTY_START_RE.find(t) ?: return null
    val qty = pre + m.groupValues[1].trim()
    val rest = m.groupValues[2].trim()
    if (TIME_WORD_RE.containsMatchIn(rest)) return null            // "5 minutes" is a duration, not a quantity
    if (rest.isNotEmpty()) {
        val parts = rest.split(WS_RE, limit = 2)
        val tok = parts[0].trimEnd('.', ',', ';')
        if (tok.lowercase() in UNITS) {
            val after = if (parts.size > 1) parts[1] else ""
            return Triple(qty, tok, after.trim(*TRIM_NAME))
        }
    }
    return Triple(qty, "", rest.trim(*TRIM_NAME))
}

/** "medium onions, finely chopped" -> ("onions", "medium, finely chopped") */
private fun splitNote(nameText: String): Pair<String, String> {
    var s = nameText.trim(*TRIM_NAME)
    val notes = mutableListOf<String>()
    for (m in PAREN_CAP_RE.findAll(s)) notes.add(m.groupValues[1].trim())
    s = PAREN_STRIP_RE.replace(s, "").trim()
    if (s.contains(',')) {
        val main = s.substringBefore(',').trim()
        val tail = s.substringAfter(',').trim(' ', ',')
        s = main
        if (tail.isNotEmpty()) notes.add(tail)
    }
    val ws = s.split(WS_RE).filter { it.isNotEmpty() }.toMutableList()
    val lead = mutableListOf<String>()
    while (ws.size > 1 && (ws[0].lowercase().trimEnd(',') in DESCR || ws[0].lowercase() in ADV)) {
        lead.add(ws.removeAt(0).trimEnd(','))
    }
    val all = mutableListOf<String>()
    if (lead.isNotEmpty()) all.add(lead.joinToString(" "))
    all.addAll(notes)
    return Pair(ws.joinToString(" "), all.joinToString(", "))
}

/** The data model has no separate "note" column, so a preparation note is kept in brackets after the name. */
private fun displayName(name: String, note: String): String {
    val n = capFirst(name.trim(*TRIM_NAME))
    return when {
        note.isNotEmpty() && n.isNotEmpty() -> "$n ($note)"
        n.isNotEmpty() -> n
        else -> note
    }
}

private fun parseIngCore(line: String): ParsedIngredient {
    var s = stripBullet(normalize(line))
    s = NUMBERING_RE.replace(s, "").trim(' ', ',', ';')

    // "Butter (50 g)"
    val pm = PAREN_QTY_RE.find(s)
    if (pm != null) {
        val u = pm.groupValues[3]
        if (u.isEmpty() || u.lowercase() in UNITS) {
            val (nm, nt) = splitNote(pm.groupValues[1])
            return ParsedIngredient(displayName(nm, nt), pm.groupValues[2].trim(), u)
        }
    }

    // "Name - qty unit", "Name: qty unit"
    val m = SEP1_RE.find(s) ?: SEP2_RE.find(s) ?: SEP3_RE.find(s)
    if (m != null && m.groupValues[1].trim().isNotEmpty()) {
        val q = parseQty(m.groupValues[2])
        if (q != null) {
            var (nm, nt) = splitNote(m.groupValues[1])
            if (q.third.isNotEmpty()) {
                nt = (if (nt.isNotEmpty()) "$nt, " else "") + OF_RE.replace(q.third, "")
            }
            return ParsedIngredient(displayName(nm, nt), q.first, q.second)
        }
    }

    // "2 tbsp oil", "250g paneer"
    val q = parseQty(s)
    if (q != null && q.first.isNotEmpty() && !FULL_RANGE_RE.matches(s)) {
        val rest = OF_RE.replace(q.third, "").trim()
        if (rest.isNotEmpty()) {
            val (nm, nt) = splitNote(rest)
            return ParsedIngredient(displayName(nm, nt), q.first, q.second)
        }
    }

    // "Paneer 250 g", "Onion 2"
    val t = TRAIL_RE.find(s)
    if (t != null) {
        val u = t.groupValues[3]
        if (u.isEmpty() || u.lowercase() in UNITS) {
            val (nm, nt) = splitNote(t.groupValues[1])
            return ParsedIngredient(displayName(nm, nt), t.groupValues[2].trim(), u)
        }
    }

    // "Salt to taste"
    val low = s.lowercase()
    if (low.length == s.length) {
        for (p in PHRASES) {
            if (low.endsWith(p) && s.length > p.length && !s[s.length - p.length - 1].isLetterOrDigit()) {
                val (nm, nt) = splitNote(s.substring(0, s.length - p.length))
                return ParsedIngredient(displayName(nm, nt), p, "")
            }
        }
    }
    val (nm, nt) = splitNote(s)
    return ParsedIngredient(displayName(nm, nt), "", "")
}

fun parseIngredientLine(line: String): ParsedIngredient {
    val p = parseIngCore(line)
    val m = APPROX_END_RE.find(p.name)
    if (m != null && p.quantity.isNotEmpty()) {
        return ParsedIngredient(
            p.name.substring(0, m.range.first).trimEnd(*TRIM_NAME),
            m.groupValues[1].trimEnd('.') + " " + p.quantity,
            p.unit
        )
    }
    return p
}

private fun isQtyOnly(line: String): Boolean {
    val s = stripBullet(normalize(line)).trim(' ', ',', ';')
    if (s.isEmpty() || ORPHAN_NUM_RE.matches(s)) return false
    val q = parseQty(s) ?: return false
    return q.third.isEmpty() && q.first.isNotEmpty()
}

private fun isTimePhrase(line: String): Boolean = TIME_PHRASE_RE.containsMatchIn(line.trim())

// ------------------------------------------------------------------------------------------ step evidence

private fun firstWord(s: String): String =
    (s.split(WS_RE).firstOrNull { it.isNotEmpty() } ?: "").trim('.', ',', ';', ':', '!', '?', '(', ')').lowercase()

private fun verbStart(s: String): Boolean {
    if (firstWord(s) in VERBS) return true
    val tk = tokens(s)
    return tk.size >= 3 && tk.takeLast(3).any { t -> HI_END.any { e -> t.trim('।', '.', ',', ';').endsWith(e) } }
}

private fun sentenceLike(s: String): Boolean {
    val tk = tokens(s)
    return tk.size >= 7 || (tk.size >= 5 && endsWithStop(s, ".।!"))
}

private fun stepEvidence(line: String): Int {
    val s = normalize(line)
    val numbered = STEP_NUM_RE.containsMatchIn(s)
    val body = STEP_STRIP_RE.replace(s, "").trim()
    val tk = tokens(body)
    if (numbered && tk.size >= 3 && (verbStart(body) || sentenceLike(body))) return 3
    if (tk.size >= 3 && verbStart(body)) return 2
    if (sentenceLike(body) && !ingStrict(body)) return 2
    return if (numbered) 1 else 0
}

/** Unmistakably written like an ingredient line, so a verb-looking first word does not turn it into a step. */
private fun ingStrict(line: String): Boolean {
    var s = stripBullet(normalize(line))
    s = NUMBERING_RE.replace(s, "").trim(' ', ',', ';')
    val tk = tokens(s)
    if (tk.isEmpty() || tk.size > 9 || s.none { it.isLetter() }) return false
    if (endsWithStop(s, ".।") && tk.size >= 6) return false
    for (rx in SEP_LIST) {
        val m = rx.find(s)
        if (m != null && m.groupValues[1].trim().isNotEmpty() && parseQty(m.groupValues[2]) != null) return true
        if (m != null) break
    }
    val q = parseQty(s)
    if (q != null && q.first.isNotEmpty() && !FULL_RANGE_RE.matches(s) && q.third.trim().isNotEmpty()) {
        return tk.size <= 8 && !isTimePhrase(s)
    }
    val t = TRAIL_RE.find(s)
    if (t != null) {
        val u = t.groupValues[3]
        if (u.isEmpty() || u.lowercase() in UNITS) return u.isNotEmpty() || (tk.size <= 4 && !verbStart(s))
    }
    val low = s.lowercase()
    return PHRASES.any { p ->
        low.endsWith(p) && s.length > p.length && low.length == s.length && !s[s.length - p.length - 1].isLetterOrDigit()
    }
}

private fun isNoise(line: String): Boolean =
    line.none { it.isLetterOrDigit() } || ORPHAN_NUM_RE.matches(line.trim())

private fun isJunk(line: String): Boolean = JUNK_RE.containsMatchIn(line) && tokens(line).size <= 10

// ------------------------------------------------------------------------------------------ layout

private fun joinText(ws: List<OcrWord>): String = ws.joinToString(" ") { it.text }

/** A recognised "line" that runs across two columns is cut at the big horizontal gap. */
private fun splitWideGaps(lines: List<OcrLine>): List<OcrLine> {
    val boxed = lines.filter { it.hasBox }
    if (boxed.isEmpty()) return lines
    val pw = boxed.maxOf { it.r } - boxed.minOf { it.l }
    val splitBlocks = HashSet<Int>()
    val pieces = ArrayList<Pair<OcrLine, List<OcrLine>?>>()
    for (x in lines) {
        var segs: List<OcrLine>? = null
        if (x.hasBox && x.words.size >= 2) {
            val thr = maxOf(2.5 * x.h, 0.05 * pw)
            val ws = x.words.sortedBy { it.l }
            var cur = mutableListOf(ws[0])
            var groups = mutableListOf<List<OcrWord>>()
            for (w in ws.drop(1)) {
                if (w.l - cur.last().r > thr) {
                    groups.add(cur)
                    cur = mutableListOf(w)
                } else {
                    cur.add(w)
                }
            }
            groups.add(cur)
            if (groups.size == 2) {
                // "Water ........ 2 cups": a name and its quantity on one row are not two columns
                val t1 = joinText(groups[0])
                val t2 = joinText(groups[1])
                if ((isQtyOnly(t2) && !isQtyOnly(t1) && parseIngredientLine(t1).quantity.isEmpty()) ||
                    (isQtyOnly(t1) && !isQtyOnly(t2) && parseIngredientLine(t2).quantity.isEmpty())
                ) {
                    groups = mutableListOf(ws)
                }
            }
            if (groups.size > 1) {
                segs = groups.map { g ->
                    OcrLine(
                        joinText(g), g.minOf { it.l }, g.minOf { it.t }, g.maxOf { it.r }, g.maxOf { it.b }, x.block, g
                    )
                }
                splitBlocks.add(x.block)
            }
        }
        pieces.add(Pair(x, segs))
    }
    val out = ArrayList<OcrLine>()
    var nxt = 1_000_000
    for ((x, segs) in pieces) {
        for (seg in (segs ?: listOf(x))) {
            if (x.block in splitBlocks) {
                // this block spans columns: every line becomes its own block
                out.add(OcrLine(seg.text, seg.l, seg.t, seg.r, seg.b, nxt, seg.words))
                nxt++
            } else {
                out.add(seg)
            }
        }
    }
    return out
}

private class Blk(val lines: List<OcrLine>, val l: Int, val t: Int, val r: Int, val b: Int)
private class Col(var l: Int, var r: Int, val items: MutableList<Blk>)

/** Reading order for multi-column posters: bands separated by full-width / stand-alone blocks, columns left to right. */
private fun orderLines(lines: List<OcrLine>): List<OcrLine> {
    if (lines.isEmpty() || !lines.all { it.hasBox }) return lines
    val byBlock = LinkedHashMap<Int, MutableList<OcrLine>>()
    for (x in lines) byBlock.getOrPut(x.block) { mutableListOf() }.add(x)
    val blocks = byBlock.values.map { ls ->
        Blk(ls, ls.minOf { it.l }, ls.minOf { it.t }, ls.maxOf { it.r }, ls.maxOf { it.b })
    }
    val pw = blocks.maxOf { it.r } - blocks.minOf { it.l }
    if (pw <= 0) return lines
    val sorted = blocks.sortedWith(compareBy<Blk>({ it.t }, { it.l }))
    val out = ArrayList<OcrLine>()
    val band = ArrayList<Blk>()

    fun flush() {
        val cols = ArrayList<Col>()
        for (b in band.sortedBy { it.l }) {
            var placed = false
            for (c in cols) {
                val ov = minOf(b.r, c.r) - maxOf(b.l, c.l)
                if (ov > 0.3 * minOf(b.r - b.l, c.r - c.l)) {
                    c.items.add(b)
                    c.l = minOf(c.l, b.l)
                    c.r = maxOf(c.r, b.r)
                    placed = true
                    break
                }
            }
            if (!placed) cols.add(Col(b.l, b.r, mutableListOf(b)))
        }
        for (c in cols.sortedBy { it.l }) {
            for (b in c.items.sortedBy { it.t }) out.addAll(b.lines)
        }
        band.clear()
    }

    fun alone(b: Blk): Boolean = blocks.none { it !== b && it.t < b.b && b.t < it.b }

    for (b in sorted) {
        if (b.r - b.l > 0.6 * pw || alone(b)) {
            flush()
            out.addAll(b.lines)
        } else {
            band.add(b)
        }
    }
    flush()
    return out
}

/** Joins a quantity-only line to the name on the same visual row (ingredient tables with separate columns). */
private fun mergeRows(lines: List<OcrLine>): List<OcrLine> {
    if (lines.isEmpty() || !lines.all { it.hasBox }) return lines
    val pw = lines.maxOf { it.r } - lines.minOf { it.l }
    val dead = HashSet<Int>()
    val repl = HashMap<Int, OcrLine>()
    for ((i, q) in lines.withIndex()) {
        if (i in dead || !isQtyOnly(q.text)) continue
        var best = -1
        var bd = Double.MAX_VALUE
        for ((j, n) in lines.withIndex()) {
            if (j == i || j in dead || j in repl || isQtyOnly(n.text)) continue
            if (headerOf(n.text) != null || fieldsOf(n.text) != null || tokens(n.text).size > 6 || stepEvidence(n.text) >= 2) continue
            if (parseIngredientLine(n.text).quantity.isNotEmpty()) continue
            if (Math.abs(n.cy - q.cy) > 0.5 * minOf(n.h, q.h)) continue
            val gap: Double = when {
                n.r <= q.l + 0.02 * pw -> (q.l - n.r).toDouble()
                q.r <= n.l + 0.02 * pw -> (n.l - q.r).toDouble()
                else -> continue
            }
            if (gap > 0.85 * pw) continue
            if (gap < bd) {
                best = j
                bd = gap
            }
        }
        if (best >= 0) {
            val n = lines[best]
            val txt = if (n.l < q.l) n.text + " - " + q.text else q.text + " " + n.text
            repl[best] = OcrLine(
                txt, minOf(n.l, q.l), minOf(n.t, q.t), maxOf(n.r, q.r), maxOf(n.b, q.b), n.block
            )
            dead.add(i)
        }
    }
    val out = ArrayList<OcrLine>()
    for ((i, x) in lines.withIndex()) if (i !in dead) out.add(repl[i] ?: x)
    return out
}

// ------------------------------------------------------------------------------------------ title

private fun titleish(s: String): String {
    val letters = s.filter { it.isLetter() }
    if (letters.isNotEmpty() && letters.all { it.code < 128 } && s == s.uppercase()) {
        return s.split(" ").filter { it.isNotEmpty() }
            .joinToString(" ") { w -> w.take(1).uppercase() + w.drop(1).lowercase() }
    }
    return s
}

/** The biggest text near the top is the title when geometry exists; otherwise the first plausible line. */
private fun pickTitle(items: List<Pair<Int, OcrLine>>, stop: Int): List<Pair<Int, OcrLine>> {
    val cands = items.filter { (i, x) ->
        i < stop && x.text.count { it.isLetter() } >= 2 && !isJunk(x.text) && !isQtyOnly(x.text)
    }
    if (cands.isEmpty()) return emptyList()
    if (cands.all { it.second.hasBox }) {
        var k = 0
        for (j in cands.indices) if (cands[j].second.h > cands[k].second.h) k = j
        val hmax = cands[k].second.h
        val pick = ArrayDeque<Pair<Int, OcrLine>>()
        pick.addLast(cands[k])
        var j = k - 1
        while (j >= 0 && cands[j].second.h >= 0.85 * hmax && Math.abs(cands[j].first - pick.first().first) == 1 &&
            Math.abs(cands[j].second.t - pick.first().second.t) < 2.2 * hmax
        ) {
            pick.addFirst(cands[j])
            j--
        }
        j = k + 1
        while (j < cands.size && cands[j].second.h >= 0.85 * hmax && Math.abs(cands[j].first - pick.last().first) == 1 &&
            Math.abs(cands[j].second.t - pick.last().second.t) < 2.2 * hmax
        ) {
            pick.addLast(cands[j])
            j++
        }
        return pick.toList()
    }
    return listOf(cands[0])
}

// ------------------------------------------------------------------------------------------ the parser

fun parseRecipeText(lines: List<String>): ParsedRecipe = parseRecipe(lines.map { OcrLine(it) })

fun parseRecipe(raw: List<OcrLine>): ParsedRecipe {
    val ols0 = raw.filter { it.text.isNotBlank() }
    val ols = mergeRows(orderLines(splitWideGaps(ols0)))
    val items: List<Pair<Int, OcrLine>> = ols.mapIndexed { i, x ->
        Pair(i, OcrLine(normalize(x.text), x.l, x.t, x.r, x.b, x.block, x.words))
    }.filter { (_, x) -> x.text.isNotEmpty() && !isNoise(x.text) }

    // first line that clearly belongs to a section; everything before it may hold the title
    var stop = ols.size + 1
    for ((i, x) in items) {
        if (headerOf(x.text) != null || fieldsOf(x.text) != null || ingStrict(x.text) || stepEvidence(x.text) >= 2) {
            stop = i
            break
        }
    }
    val titleItems = pickTitle(items, stop)
    val titleIdx = titleItems.map { it.first }.toSet()
    val name = if (titleItems.isEmpty()) "" else titleish(titleItems.joinToString(" ") { it.second.text.trim() })

    val ings = mutableListOf<ParsedIngredient>()
    val groups = mutableListOf<String>()
    val steps = mutableListOf<String>()
    val notes = mutableListOf<String>()
    val unclassified = mutableListOf<String>()
    var prep = ""
    var cook = ""
    var total = ""
    var serv = ""
    var section: String? = null
    var group = ""
    var stepsNumbered: Boolean? = null

    val seq = items.filter { it.first !in titleIdx }.toMutableList()
    var k = 0
    while (k < seq.size) {
        val (i, x) = seq[k]
        k++
        val line = x.text
        if (isJunk(line)) {
            unclassified.add(line)
            continue
        }

        val f = fieldsOf(line)
        if (f != null) {
            for ((kd, v0) in f) {
                var v = v0
                if (v.isEmpty() && f.size == 1 && k < seq.size && seq[k].second.text.any { it.isDigit() } &&
                    headerOf(seq[k].second.text) == null && fieldsOf(seq[k].second.text) == null
                ) {
                    v = seq[k].second.text.trim()
                    k++
                }
                if (v.isNotEmpty()) {
                    when (kd) {
                        "prep" -> { prep = v }
                        "cook" -> { cook = v }
                        "total" -> { total = v }
                        else -> { serv = v }
                    }
                }
            }
            continue
        }

        val h = headerOf(line, section)
        if (h != null) {
            section = h.first
            if (section == "ing") group = h.third
            if (h.second.isNotEmpty()) seq.add(k, Pair(i, OcrLine(h.second, x.l, x.t, x.r, x.b, x.block)))
            continue
        }

        val numbered = STEP_NUM_RE.containsMatchIn(line)
        val body = STEP_STRIP_RE.replace(line, "").trim()
        val ev = stepEvidence(line)
        val strict = ingStrict(line)
        val qtyOnly = isQtyOnly(line)

        fun addStep() {
            if (stepsNumbered == null) stepsNumbered = numbered
            val prev = if (steps.isNotEmpty()) steps[steps.size - 1] else ""
            val wrapped = prev.isNotEmpty() && !numbered && !endsWithStop(prev, ".।!?:") &&
                (body.firstOrNull()?.isLowerCase() == true || !verbStart(body))
            if (wrapped) {
                steps[steps.size - 1] = prev + " " + body
            } else if (body.isNotEmpty()) {
                steps.add(body)
            }
        }

        fun addIng(txt: String) {
            ings.add(parseIngredientLine(txt))
            groups.add(group)
        }

        if (section == "note") {
            notes.add(line)
            continue
        }

        if (section == "ing") {
            if (qtyOnly) {
                // a column of quantities that follows a column of names: pair them only when the counts match
                var mRun = 1
                while (k - 1 + mRun < seq.size && isQtyOnly(seq[k - 1 + mRun].second.text)) mRun++
                var tail = 0
                for (j in ings.indices.reversed()) {
                    if (ings[j].quantity.isEmpty()) tail++ else break
                }
                if (tail >= 1 && mRun == tail) {
                    for (t in 0 until mRun) {
                        val q = parseQty(seq[k - 1 + t].second.text.trim(' ', ',', ';', '-', '–', '—', ':')) ?: continue
                        val idx = ings.size - mRun + t
                        ings[idx] = ParsedIngredient(ings[idx].name, q.first, q.second)
                    }
                    k += mRun - 1
                } else {
                    unclassified.add(line)
                }
                continue
            }
            if (isTimePhrase(line)) {
                if (steps.isNotEmpty()) steps[steps.size - 1] = steps[steps.size - 1] + " " + line
                else unclassified.add(line)
                continue
            }
            if (strict && !(numbered && ev >= 3)) {
                addIng(line)
                continue
            }
            if (ev >= 2) {
                section = "step"
                addStep()
                continue
            }
            val tk = tokens(line)
            if (tk.size <= 6 && !line.trimEnd().endsWith(".") && !line.trimEnd().endsWith("।")) addIng(line)
            else unclassified.add(line)
            continue
        }

        if (section == "step") {
            if (numbered && ev >= 1 && !(strict && !verbStart(body))) {
                addStep()
                continue
            }
            if (strict && !verbStart(line) && !numbered && tokens(line).size <= 6 && !isTimePhrase(line)) {
                addIng(line)
                continue
            }
            if (LONE_NUM_RE.matches(line.trim())) continue          // a lone step number split off by the OCR engine
            if (qtyOnly && !isTimePhrase(line)) {
                unclassified.add(line)
                continue
            }
            if (isTimePhrase(line)) {
                if (steps.isNotEmpty()) steps[steps.size - 1] = steps[steps.size - 1] + " " + line
                else unclassified.add(line)
                continue
            }
            addStep()
            continue
        }

        // no section yet
        if (ev >= 2 && !strict) {
            section = "step"
            addStep()
            continue
        }
        if (strict) {
            section = "ing"
            addIng(line)
            continue
        }
        unclassified.add(line)
    }

    // the same ingredient in two groups: keep the group in the name so they stay distinguishable
    val counts = HashMap<String, Int>()
    for (n in ings) counts[n.name.lowercase()] = (counts[n.name.lowercase()] ?: 0) + 1
    val finalIngs = ings.mapIndexed { j, n ->
        if ((counts[n.name.lowercase()] ?: 0) > 1 && groups[j].isNotEmpty()) {
            ParsedIngredient(n.name + " (" + groups[j] + ")", n.quantity, n.unit)
        } else {
            n
        }
    }
    return ParsedRecipe(name, finalIngs, steps, prep, cook, total, serv, notes.joinToString("\n"), unclassified)
}

/** Only picks a category whose name literally appears in the first lines of the scan; otherwise blank. */
fun guessCategory(headText: String, names: List<String>): String {
    val low = headText.lowercase()
    for (n in names) {
        val ln = n.lowercase()
        if (ln == OTHER_CATEGORY.lowercase()) continue
        if (Regex("\\b" + Regex.escape(ln) + "\\b").containsMatchIn(low)) return n
    }
    if (Regex("\\b(dessert|desserts|sweet|sweets)\\b").containsMatchIn(low)) {
        val d = names.firstOrNull { it.contains("dessert", ignoreCase = true) }
        if (d != null) return d
    }
    return ""
}
