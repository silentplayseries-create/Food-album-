package com.foodalbum.app

/**
 * Turns raw OCR lines into recipe fields. This is only a first guess:
 * anything it cannot classify is kept (in Notes) and the full OCR text is always available to the user.
 * Missing / uncertain fields stay blank — nothing is invented.
 */

data class ParsedIngredient(val name: String, val quantity: String, val unit: String)

data class ParsedRecipe(
    val name: String,
    val ingredients: List<ParsedIngredient>,
    val steps: List<String>,
    val prepTime: String,
    val cookTime: String,
    val totalTime: String,
    val servings: String,
    val notes: String
)

private const val FR = "½¼¾⅓⅔"
private const val NUM = """(?:\d+\s+\d+/\d+|\d+/\d+|\d+(?:[.,]\d+)?[$FR]?|[$FR])"""
private const val RANGE = NUM + """(?:\s*(?:-|–|—|to)\s*""" + NUM + """)?"""

private val UNITS: Set<String> = (
    "g gm gms gram grams kg kgs kilogram kilograms mg ml l ltr litre litres liter liters cup cups " +
        "tbsp tablespoon tablespoons tsp teaspoon teaspoons oz ounce ounces lb lbs pound pounds " +
        "pinch pinches piece pieces pcs pc clove cloves slice slices bunch bunches handful sprig sprigs " +
        "stick sticks inch inches nos can cans packet packets glass glasses ग्राम किलो चम्मच कप लीटर"
    ).split(" ").toSet()

private val PHRASES: List<String> = listOf(
    "to taste", "as required", "as needed", "as per taste", "as per requirement", "as desired",
    "a pinch", "a handful", "a few", "pinch", "handful", "few", "some",
    "स्वादानुसार", "आवश्यकतानुसार"
).sortedByDescending { it.length }

private val ING_H = setOf(
    "ingredients", "ingredient", "ingredients list", "what you need", "you will need", "सामग्री", "आवश्यक सामग्री"
)
private val STEP_H = setOf(
    "instructions", "instruction", "method", "directions", "direction", "preparation", "procedure", "steps",
    "how to make", "how to cook", "preparation method", "cooking instructions", "cooking method", "recipe",
    "विधि", "बनाने की विधि", "बनाने का तरीका", "तरीका"
)
private val NOTE_H = setOf("notes", "note", "tips", "tip", "chefs tip", "chef's tip", "नोट", "टिप्स")

private const val LABELS =
    "(?:prep(?:aration)?\\s*time|cook(?:ing)?\\s*time|total\\s*time|ready\\s*in|serves|servings?(?:\\s*size)?|yields?|" +
        "तैयारी का समय|पकाने का समय|बनाने का समय|कुल समय|prep|cook)"
private val LABEL_RE = Regex(LABELS + "(?:\\s*[:\\-–—]\\s*|\\s+(?=\\d)|\\s*$)", RegexOption.IGNORE_CASE)
private val BARE_LABEL_RE = Regex("^(prep|cook)\\s*[:\\-–—\\s]*$", RegexOption.IGNORE_CASE)

private val BULLET_RE = Regex("^[\\s•*·▪■□☐☑✓✔>\\-–—]+")
private val NUMBERING_RE = Regex("^\\d+\\s*[.)]\\s+(?=\\D)")
private val STEP_NUM_RE = Regex("^\\s*(?:step\\s*\\d+|\\d+\\s*[.)])\\s*", RegexOption.IGNORE_CASE)
private val STEP_STRIP_RE = Regex(
    "^(?:step\\s*\\d+\\s*[:.\\-–)]?\\s*|\\d+\\s*[.)]\\s+|[•*\\-–·▪]\\s*)",
    RegexOption.IGNORE_CASE
)
private val QTY_START_RE = Regex("^(" + RANGE + ")\\s*(.*)$")
private val FULL_RANGE_RE = Regex(RANGE)
private val SEP1_RE = Regex("^(.*?)\\s+[-–—]+\\s+(.+)$")
private val SEP2_RE = Regex("^(.*?)\\s*:\\s*(.+)$")
private val SEP3_RE = Regex("^(.*?)\\s+[-–—]\\s*(\\d.*)$")
private val TRAIL_RE = Regex("^(.*\\S)\\s+(" + RANGE + ")(?:\\s*([A-Za-z]+)\\.?)?\\s*$")
private val OF_RE = Regex("^of\\s+", RegexOption.IGNORE_CASE)
private val WS_RE = Regex("\\s+")

private val VAL_TRIM = charArrayOf(' ', '|', ',', ';', '•', '·', '-', '–', '—', '/')
private val REST_TRIM = charArrayOf(' ', ',', ';', '-', '–', '—')

private fun kindOf(label: String): String {
    val l = label.lowercase()
    return when {
        l.contains("prep") || l.contains("तैयारी") -> "prep"
        l.contains("total") || l.contains("ready") || l.contains("कुल") -> "total"
        l.contains("cook") || l.contains("पकाने") || l.contains("बनाने का समय") -> "cook"
        else -> "serv"
    }
}

private fun normHeader(x: String): String =
    x.replace(Regex("^[\\s•*\\-–—]+"), "")
        .replace(Regex("[\\s:.\\-–—•*]+$"), "")
        .trim()
        .lowercase()

/** Returns ("ing" | "step" | "note", text-after-colon) when the line is a section header. */
private fun headerOf(line: String): Pair<String, String>? {
    val t = line.trim()
    val idx = t.indexOf(':')
    val candidates = mutableListOf(normHeader(t) to "")
    if (idx >= 0) candidates.add(normHeader(t.substring(0, idx)) to t.substring(idx + 1).trim())
    for ((src, rest) in candidates) {
        val kind = when {
            src in ING_H -> "ing"
            src in STEP_H -> "step"
            src in NOTE_H -> "note"
            else -> null
        }
        if (kind != null) return Pair(kind, rest)
    }
    return null
}

/** Handles "Cooking Time: 30 min" and also "Prep: 20 min | Cook: 20 min | Serves 5". */
private fun fieldsOf(line: String): List<Pair<String, String>>? {
    val ms = LABEL_RE.findAll(line).toList()
    if (ms.isEmpty() || ms[0].range.first > 3) return null
    val out = mutableListOf<Pair<String, String>>()
    for ((i, m) in ms.withIndex()) {
        val end = if (i + 1 < ms.size) ms[i + 1].range.first else line.length
        val value = line.substring(m.range.last + 1, end).trim(*VAL_TRIM)
        val txt = m.value
        if (BARE_LABEL_RE.matches(txt)) {
            // bare "Prep:" / "Cook:" only count with a colon and a number after it
            if (!txt.contains(':') || !value.any { it.isDigit() }) return null
        }
        out.add(Pair(kindOf(txt), value))
    }
    return out
}

/** Returns (quantity, unit, leftover text) or null if the text does not start with a quantity. */
private fun parseQty(text: String): Triple<String, String, String>? {
    val t = text.trim()
    val low = t.lowercase()
    for (p in PHRASES) {
        if (low.startsWith(p) && (t.length == p.length || !t[p.length].isLetterOrDigit())) {
            return Triple(p, "", t.substring(p.length).trim(*REST_TRIM))
        }
    }
    val m = QTY_START_RE.find(t) ?: return null
    val qty = m.groupValues[1].trim()
    val rest = m.groupValues[2].trim()
    if (rest.isNotEmpty()) {
        val parts = rest.split(WS_RE, limit = 2)
        val tok = parts[0].trimEnd('.', ',', ';')
        if (tok.lowercase() in UNITS) {
            val after = if (parts.size > 1) parts[1] else ""
            return Triple(qty, tok, after.trim(*REST_TRIM))
        }
    }
    return Triple(qty, "", rest.trim(*REST_TRIM))
}

private fun joinName(name: String, extraIn: String): String {
    val extra = extraIn.replace(OF_RE, "").trim()
    return when {
        extra.isEmpty() -> name
        name.isEmpty() -> extra
        extra.startsWith("(") -> "$name $extra"
        else -> "$name, $extra"
    }
}

private fun ing(name: String, qty: String, unit: String): ParsedIngredient {
    val n = name.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() }
    return ParsedIngredient(n, qty, unit)
}

fun parseIngredientLine(line: String): ParsedIngredient {
    var s = BULLET_RE.replace(line.trim(), "")
    s = NUMBERING_RE.replace(s, "").trim(' ', ',', ';')

    // "Name - qty unit", "Name: qty unit"
    val m = SEP1_RE.find(s) ?: SEP2_RE.find(s) ?: SEP3_RE.find(s)
    if (m != null && m.groupValues[1].trim().isNotEmpty()) {
        val q = parseQty(m.groupValues[2])
        if (q != null) return ing(joinName(m.groupValues[1].trim(), q.third), q.first, q.second)
    }

    // "2 tbsp oil", "250g paneer"
    val q = parseQty(s)
    if (q != null && q.first.isNotEmpty() && !FULL_RANGE_RE.matches(s)) {
        val name = q.third.replace(OF_RE, "").trim()
        if (name.isNotEmpty()) return ing(name, q.first, q.second)
    }

    // "Paneer 250 g", "Onion 2"
    val t = TRAIL_RE.find(s)
    if (t != null) {
        val unitWord = t.groupValues[3]
        if (unitWord.isEmpty() || unitWord.lowercase() in UNITS) {
            return ing(t.groupValues[1].trim(' ', ',', ';', '-', '–', '—'), t.groupValues[2].trim(), unitWord)
        }
    }

    // "Salt to taste"
    val low = s.lowercase()
    if (low.length == s.length) {
        for (p in PHRASES) {
            if (low.endsWith(p) && s.length > p.length && !s[s.length - p.length - 1].isLetterOrDigit()) {
                return ing(s.substring(0, s.length - p.length).trim(' ', ',', ';', '-', '–', '—', ':'), p, "")
            }
        }
    }
    return ing(s, "", "")
}

private fun titleish(s: String): String {
    val letters = s.filter { it.isLetter() }
    if (letters.isNotEmpty() && letters.all { it.code < 128 } && s == s.uppercase()) {
        return s.split(" ").filter { it.isNotEmpty() }
            .joinToString(" ") { w -> w.take(1).uppercase() + w.drop(1).lowercase() }
    }
    return s
}

fun parseRecipe(rawLines: List<String>): ParsedRecipe {
    val lines = rawLines.map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
    var name = ""
    val ings = mutableListOf<ParsedIngredient>()
    val steps = mutableListOf<String>()
    val notes = mutableListOf<String>()
    val unsorted = mutableListOf<String>()
    var prep = ""
    var cook = ""
    var total = ""
    var serv = ""
    var section: String? = null
    var stepsNumbered: Boolean? = null

    var i = 0
    while (i < lines.size) {
        val line = lines[i]
        i++

        val f = fieldsOf(line)
        if (f != null) {
            for ((k, v0) in f) {
                var v = v0
                if (v.isEmpty() && f.size == 1 && i < lines.size && lines[i].any { it.isDigit() } &&
                    headerOf(lines[i]) == null && fieldsOf(lines[i]) == null
                ) {
                    v = lines[i].trim()
                    i++
                }
                if (v.isNotEmpty()) {
                    when (k) {
                        "prep" -> { prep = v }
                        "cook" -> { cook = v }
                        "total" -> { total = v }
                        else -> { serv = v }
                    }
                }
            }
            continue
        }

        val h = headerOf(line)
        if (h != null) {
            section = h.first
            if (h.second.isNotEmpty()) lines.add(i, h.second)
            continue
        }

        when (section) {
            null -> {
                // before any header: title first, then best-effort per-line guessing
                if (name.isEmpty() && line.count { it.isLetter() } >= 2 && !STEP_NUM_RE.containsMatchIn(line)) {
                    name = titleish(line.trim())
                } else if (STEP_NUM_RE.containsMatchIn(line)) {
                    steps.add(STEP_STRIP_RE.replace(line, "").trim())
                } else {
                    val p = parseIngredientLine(line)
                    if (p.quantity.isNotEmpty()) ings.add(p) else unsorted.add(line)
                }
            }
            "ing" -> {
                val p = parseIngredientLine(line)
                if (p.name.isNotEmpty() || p.quantity.isNotEmpty()) ings.add(p)
            }
            "step" -> {
                val numbered = STEP_NUM_RE.containsMatchIn(line)
                if (stepsNumbered == null) stepsNumbered = numbered
                val text = STEP_STRIP_RE.replace(line, "").trim()
                if (steps.isNotEmpty() && stepsNumbered == true && !numbered) {
                    steps[steps.size - 1] = steps[steps.size - 1] + " " + text
                } else if (text.isNotEmpty()) {
                    steps.add(text)
                }
            }
            else -> notes.add(line)
        }
    }

    val noteText = buildString {
        append(notes.joinToString("\n"))
        if (unsorted.isNotEmpty()) {
            if (isNotEmpty()) append("\n\n")
            append("Unsorted text from scan:\n")
            append(unsorted.joinToString("\n"))
        }
    }
    return ParsedRecipe(name, ings, steps, prep, cook, total, serv, noteText)
}

/** Only picks a category whose name literally appears in the first lines of the scan; otherwise blank. */
fun guessCategory(headText: String, names: List<String>): String {
    val low = headText.lowercase()
    for (n in names) {
        val ln = n.lowercase()
        if (ln == OTHER_CATEGORY.lowercase()) continue
        if (Regex("\\b" + Regex.escape(ln) + "\\b").containsMatchIn(low)) return n
    }
    if (Regex("\\b(dessert|desserts|sweet|sweets)\\b").containsMatchIn(low)) {
        val d = names.firstOrNull { it.contains("dessert", ignoreCase = true) }
        if (d != null) return d
    }
    return ""
}
