package com.foodalbum.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun HomeScreen(
    vm: AppViewModel,
    onOpen: (Long) -> Unit,
    onAdd: () -> Unit,
    onScan: () -> Unit,
    onTab: (String) -> Unit
) {
    val recipes by vm.recipes.collectAsState()
    val ings by vm.ingredientNames.collectAsState()
    val cats by vm.categories.collectAsState()
    val all = recipes ?: emptyList()

    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<String?>(null) }
    var sort by remember { mutableStateOf(SortMode.RECENT) }

    val shown = remember(all, ings, query, filter, sort) { filterAndSort(all, ings, query, filter, sort) }
    val searching = query.isNotBlank() || filter != null

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = { BottomNav("home", onTab) },
        floatingActionButton = {
            ExtendedFloatingActionButton(onClick = onAdd, containerColor = Orange, contentColor = Color.Black) {
                Icon(Icons.Default.Add, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Add Recipe", fontWeight = FontWeight.Bold)
            }
        }
    ) { pad ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize(),
            contentPadding = gridPadding(pad, extraBottom = 88.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            fullWidth { HomeHeader(count = all.size) }
            fullWidth {
                OutlinedButton(
                    onClick = onScan,
                    border = BorderStroke(1.5.dp, Orange),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                ) {
                    Text("📷  Scan Recipe", color = Orange, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
            fullWidth { SearchField(query) { query = it } }
            fullWidth { CategoryChips(cats.map { it.name }, filter) { filter = it } }
            if (all.isNotEmpty()) {
                fullWidth {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when {
                                searching -> "${recipeCount(shown.size)} found"
                                sort == SortMode.RECENT -> "Recently Added"
                                else -> "All Recipes"
                            },
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Gold
                        )
                        SortMenu(sort) { sort = it }
                    }
                }
            }
            if (recipes != null && all.isEmpty()) {
                fullWidth { EmptyState("🍽️", "No recipes yet", "Tap “Add Recipe” to save your first one.") }
            } else if (all.isNotEmpty() && shown.isEmpty()) {
                fullWidth { EmptyState("🔎", "No matching recipes", "Try a different word or category.") }
            }
            recipeItems(shown, onOpen) { vm.toggleFavourite(it) }
        }
    }
}

@Composable
private fun HomeHeader(count: Int) {
    Column(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(Orange),
                contentAlignment = Alignment.Center
            ) { Text("🍳", fontSize = 24.sp) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Food Album", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                Text("Save • Organize • Cook • Enjoy", color = Gold, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Your Recipe Collection", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            if (count == 1) "1 recipe saved" else "$count recipes saved",
            color = TextSecondary,
            fontSize = 14.sp
        )
    }
}

@Composable
fun RecipeCard(r: Recipe, onClick: () -> Unit, onFav: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Card(
        modifier = Modifier
            .clip(shape)
            .clickable(onClick = onClick),
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = CardBg),
        border = BorderStroke(1.dp, BorderGrey)
    ) {
        Box {
            RecipeImage(
                path = r.imagePath,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.8f),
                contentScale = ContentScale.Crop,
                minSide = 500,
                compactPlaceholder = true
            )
            IconButton(
                onClick = onFav,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(6.dp)
                    .size(40.dp)
                    .background(Color.Black.copy(alpha = 0.45f), CircleShape)
            ) {
                Icon(
                    Icons.Default.Favorite,
                    contentDescription = "Favourite",
                    tint = if (r.favourite) Orange else Color.White.copy(alpha = 0.8f)
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            Text(
                r.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(r.category, color = Gold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (r.cookTime.isNotBlank()) {
                Text(
                    "⏱ ${r.cookTime}",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
    }
}
