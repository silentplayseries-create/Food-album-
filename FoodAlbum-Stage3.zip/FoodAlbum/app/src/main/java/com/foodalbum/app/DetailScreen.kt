package com.foodalbum.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DetailScreen(
    vm: AppViewModel,
    id: Long,
    onBack: () -> Unit,
    onEdit: () -> Unit,
    onCook: () -> Unit,
    onViewImage: () -> Unit
) {
    val recipe by remember(id) { vm.recipe(id) }.collectAsState(initial = null)
    val ings by remember(id) { vm.ingredients(id) }.collectAsState(initial = emptyList())
    val steps by remember(id) { vm.steps(id) }.collectAsState(initial = emptyList())
    var confirmDelete by remember { mutableStateOf(false) }
    var showOcr by remember { mutableStateOf(false) }

    LaunchedEffect(id) { vm.markViewed(id) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) vm.replaceImage(id, uri)
    }
    val pickImage = {
        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    val r = recipe

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            AppTopBar(
                title = "Recipe",
                onBack = onBack,
                actions = {
                    if (r != null) {
                        IconButton(onClick = { vm.toggleFavourite(r) }) {
                            Icon(
                                Icons.Default.Favorite,
                                contentDescription = "Favourite",
                                tint = if (r.favourite) Orange else TextSecondary
                            )
                        }
                    }
                }
            )
        }
    ) { pad ->
        if (r != null) {
            Column(
                modifier = Modifier
                    .padding(pad)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ---- Image ----
                val shape = RoundedCornerShape(20.dp)
                if (r.imagePath == null) {
                    ImagePlaceholder(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(240.dp)
                            .clip(shape),
                        onAddImage = { pickImage() }
                    )
                } else {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .clip(shape)
                            .background(CardBg)
                            .clickable { onViewImage() },
                        contentAlignment = Alignment.Center
                    ) {
                        RecipeImage(
                            path = r.imagePath,
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 120.dp, max = 460.dp),
                            contentScale = ContentScale.Fit,
                            minSide = 1200,
                            onAddImage = { pickImage() }
                        )
                    }
                }

                // ---- Header ----
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(r.name, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 34.sp)
                    Text(r.category, color = Gold, fontWeight = FontWeight.SemiBold)
                    if (r.description.isNotBlank()) Text(r.description, color = TextSecondary, fontSize = 15.sp)
                }
                val pills = listOf(
                    "Prep" to r.prepTime,
                    "Cook" to r.cookTime,
                    "Total" to r.totalTime,
                    "Serves" to r.servings,
                    "Level" to r.difficulty
                ).filter { it.second.isNotBlank() }
                if (pills.isNotEmpty()) {
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        pills.forEach { (l, v) -> InfoPill(l, v) }
                    }
                }

                // ---- Actions ----
                Button(
                    onClick = onCook,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange, contentColor = Color.Black)
                ) { Text("Start Cooking", fontSize = 18.sp, fontWeight = FontWeight.Bold) }

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onEdit) { Text("Edit Recipe") }
                    OutlinedButton(onClick = { pickImage() }) {
                        Text(if (r.imagePath == null) "Add Image" else "Change Image")
                    }
                    if (r.imagePath != null) {
                        OutlinedButton(onClick = { vm.removeImage(id) }) { Text("Remove Image") }
                    }
                    OutlinedButton(onClick = { confirmDelete = true }) { Text("Delete Recipe", color = Danger) }
                }

                // ---- Ingredients ----
                SectionTitle("Ingredients")
                ChecklistBlock(
                    ingredients = ings,
                    large = false,
                    onToggle = { ing, v -> vm.setChecked(ing, v) },
                    onCheckAll = if (ings.isNotEmpty()) ({ vm.checkAll(id) }) else null,
                    onReset = if (ings.isNotEmpty()) ({ vm.resetChecklist(id) }) else null
                )

                // ---- Method ----
                SectionTitle("Cooking Method")
                if (steps.isEmpty()) {
                    Text("No cooking steps added.", color = TextSecondary)
                } else {
                    steps.forEachIndexed { i, s ->
                        Row(verticalAlignment = Alignment.Top) {
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(Orange),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("${i + 1}", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.width(12.dp))
                            Text(
                                s.text,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(top = 3.dp),
                                fontSize = 18.sp,
                                lineHeight = 26.sp
                            )
                        }
                    }
                }

                // ---- Notes ----
                if (r.notes.isNotBlank()) {
                    SectionTitle("Personal Notes")
                    Text(r.notes, fontSize = 16.sp, lineHeight = 24.sp, color = TextSecondary)
                }

                // ---- Original scanned text (only for recipes created with Scan Recipe) ----
                if (r.ocrText.isNotBlank()) {
                    TextButton(onClick = { showOcr = !showOcr }) {
                        Text(
                            if (showOcr) "Hide Original Scanned Text ▲" else "Show Original Scanned Text ▼",
                            color = Gold
                        )
                    }
                    if (showOcr) {
                        SelectionContainer {
                            Text(r.ocrText, fontSize = 14.sp, lineHeight = 21.sp, color = TextSecondary)
                        }
                    }
                }
                Spacer(Modifier.height(24.dp))
            }

            if (confirmDelete) {
                AlertDialog(
                    onDismissRequest = { confirmDelete = false },
                    title = { Text("Delete recipe?") },
                    text = { Text("“${r.name}” and its image will be permanently deleted.") },
                    confirmButton = {
                        TextButton(onClick = {
                            confirmDelete = false
                            vm.deleteRecipe(id, onBack)
                        }) { Text("Delete", color = Danger) }
                    },
                    dismissButton = {
                        TextButton(onClick = { confirmDelete = false }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}
