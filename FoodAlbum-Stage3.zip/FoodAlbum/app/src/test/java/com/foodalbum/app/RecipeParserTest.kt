package com.foodalbum.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Parser tests (JVM unit tests, no Android needed).
 * Generated from the same cases that were run against the Python reference implementation of the parser.
 * Run with:  gradle testDebugUnitTest
 */
class RecipeParserTest {

    @Test
    fun case01_simple_one_per_line_spec_sample() {
        // simple one-per-line (spec sample)
        val r = parseRecipeText(listOf(
            "DHABA STYLE MATAR PANEER",
            "Ingredients:",
            "Paneer - 250 g",
            "Green peas - 1 cup",
            "Onion - 2",
            "Tomato - 2",
            "Ginger garlic paste - 1 tbsp",
            "Oil - 2 tbsp",
            "Salt - to taste",
            "Instructions:",
            "1. Prepare the masala.",
            "2. Cook the masala.",
            "3. Add peas and paneer.",
            "4. Simmer until ready.",
            "Cooking Time: 30 minutes",
            "Serves: 3-4"
        ))
        assertEquals("Dhaba Style Matar Paneer", r.name)
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Green peas", "1", "cup"), ParsedIngredient("Onion", "2", ""), ParsedIngredient("Tomato", "2", ""), ParsedIngredient("Ginger garlic paste", "1", "tbsp"), ParsedIngredient("Oil", "2", "tbsp"), ParsedIngredient("Salt", "to taste", "")), r.ingredients)
        assertEquals(listOf("Prepare the masala.", "Cook the masala.", "Add peas and paneer.", "Simmer until ready."), r.steps)
        assertEquals("", r.prepTime)
        assertEquals("30 minutes", r.cookTime)
        assertEquals("", r.totalTime)
        assertEquals("3-4", r.servings)
        assertEquals(listOf(), r.unclassified)
    }

    @Test
    fun case02_multiple_ingredient_sections_duplicate_salt() {
        // multiple ingredient sections + duplicate salt
        val r = parseRecipeText(listOf(
            "Paneer Tikka",
            "For the Marinade:",
            "Paneer - 250 g",
            "Thick curd - 1/2 cup",
            "Salt - 1 tsp",
            "For the Gravy",
            "Onion - 2",
            "Tomato puree - 1 cup",
            "Salt - to taste",
            "Method",
            "1. Mix the marinade and coat the paneer.",
            "2. Grill for 10 minutes."
        ))
        assertEquals("Paneer Tikka", r.name)
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Thick curd", "1/2", "cup"), ParsedIngredient("Salt (marinade)", "1", "tsp"), ParsedIngredient("Onion", "2", ""), ParsedIngredient("Tomato puree", "1", "cup"), ParsedIngredient("Salt (gravy)", "to taste", "")), r.ingredients)
        assertEquals(listOf("Mix the marinade and coat the paneer.", "Grill for 10 minutes."), r.steps)
    }

    @Test
    fun case03_quantities_and_units() {
        // quantities and units
        val r = parseRecipeText(listOf(
            "Ingredients",
            "Sugar 1/2 cup",
            "2 tbsp oil",
            "Flour - 250g",
            "Milk 200-250 ml",
            "Green chillies - 10–12 pieces",
            "Cardamom - 4 pods",
            "Butter (50 g)",
            "Water about 1 cup",
            "Pinch of salt",
            "Turmeric 1 tsp"
        ))
        assertEquals(listOf(ParsedIngredient("Sugar", "1/2", "cup"), ParsedIngredient("Oil", "2", "tbsp"), ParsedIngredient("Flour", "250", "g"), ParsedIngredient("Milk", "200-250", "ml"), ParsedIngredient("Green chillies", "10–12", "pieces"), ParsedIngredient("Cardamom", "4", "pods"), ParsedIngredient("Butter", "50", "g"), ParsedIngredient("Water", "about 1", "cup"), ParsedIngredient("Salt", "pinch", ""), ParsedIngredient("Turmeric", "1", "tsp")), r.ingredients)
    }

    @Test
    fun case04_salt_to_taste_variants_notes() {
        // salt to taste variants + notes
        val r = parseRecipeText(listOf(
            "Ingredients",
            "Salt to taste",
            "Black pepper - as required",
            "2 medium onions, finely chopped",
            "Coriander leaves, chopped - 2 tbsp",
            "Oil for frying"
        ))
        assertEquals(listOf(ParsedIngredient("Salt", "to taste", ""), ParsedIngredient("Black pepper", "as required", ""), ParsedIngredient("Onions (medium, finely chopped)", "2", ""), ParsedIngredient("Coriander leaves (chopped)", "2", "tbsp"), ParsedIngredient("Oil for frying", "", "")), r.ingredients)
    }

    @Test
    fun case05_numbered_steps_are_not_ingredients_step_with_quantity_stays_a_step() {
        // numbered steps are not ingredients; step with quantity stays a step
        val r = parseRecipeText(listOf(
            "Aloo Jeera",
            "Ingredients",
            "Potato - 4",
            "Cumin - 1 tsp",
            "Oil - 2 tbsp",
            "Method",
            "1. Heat the oil in a pan.",
            "2. Add 2 tablespoons of oil to the pan and add cumin.",
            "3. Add the boiled potatoes and cook",
            "for 5 minutes.",
            "4. Serve hot."
        ))
        assertEquals("Aloo Jeera", r.name)
        assertEquals(listOf(ParsedIngredient("Potato", "4", ""), ParsedIngredient("Cumin", "1", "tsp"), ParsedIngredient("Oil", "2", "tbsp")), r.ingredients)
        assertEquals(listOf("Heat the oil in a pan.", "Add 2 tablespoons of oil to the pan and add cumin.", "Add the boiled potatoes and cook for 5 minutes.", "Serve hot."), r.steps)
    }

    @Test
    fun case06_missing_method_heading_implicit_switch_to_steps() {
        // missing method heading: implicit switch to steps
        val r = parseRecipeText(listOf(
            "Egg Curry",
            "Ingredients",
            "Eggs - 4",
            "Onion - 2",
            "Oil - 2 tbsp",
            "Heat oil in a pan and fry the onions until golden.",
            "Add the boiled eggs and cook for 5 minutes.",
            "Serve with rice."
        ))
        assertEquals("Egg Curry", r.name)
        assertEquals(listOf(ParsedIngredient("Eggs", "4", ""), ParsedIngredient("Onion", "2", ""), ParsedIngredient("Oil", "2", "tbsp")), r.ingredients)
        assertEquals(listOf("Heat oil in a pan and fry the onions until golden.", "Add the boiled eggs and cook for 5 minutes.", "Serve with rice."), r.steps)
    }

    @Test
    fun case07_no_headings_at_all() {
        // no headings at all
        val r = parseRecipeText(listOf(
            "Masala Chai",
            "2 cups water",
            "1 tsp tea leaves",
            "1 inch ginger",
            "Boil the water with ginger and tea leaves.",
            "Add milk and simmer for 2 minutes."
        ))
        assertEquals("Masala Chai", r.name)
        assertEquals(listOf(ParsedIngredient("Water", "2", "cups"), ParsedIngredient("Tea leaves", "1", "tsp"), ParsedIngredient("Ginger", "1", "inch")), r.ingredients)
        assertEquals(listOf("Boil the water with ginger and tea leaves.", "Add milk and simmer for 2 minutes."), r.steps)
    }

    @Test
    fun case08_Hindi_recipe() {
        // Hindi recipe
        val r = parseRecipeText(listOf(
            "मटर पनीर",
            "सामग्री:",
            "पनीर - 250 ग्राम",
            "प्याज़ - 2",
            "नमक - स्वादानुसार",
            "विधि:",
            "1. कड़ाही में तेल गरम करें।",
            "2. प्याज़ डालकर भूनें।",
            "तैयारी का समय: 15 मिनट",
            "कितने लोगों के लिए: 4"
        ))
        assertEquals("मटर पनीर", r.name)
        assertEquals(listOf(ParsedIngredient("पनीर", "250", "ग्राम"), ParsedIngredient("प्याज़", "2", ""), ParsedIngredient("नमक", "स्वादानुसार", "")), r.ingredients)
        assertEquals(listOf("कड़ाही में तेल गरम करें।", "प्याज़ डालकर भूनें।"), r.steps)
        assertEquals("15 मिनट", r.prepTime)
        assertEquals("4", r.servings)
    }

    @Test
    fun case09_OCR_spelling_mistakes() {
        // OCR spelling mistakes
        val r = parseRecipeText(listOf(
            "Veg Pulao",
            "lngredients",
            "Basmati rice - 2OO g",
            "Ginger garlic paste - l tbsp",
            "Salt - to taste",
            "Methad",
            "1. Wash and soak the rice.",
            "2. Cook everything together.",
            "Cookmg Time: 25 mins"
        ))
        assertEquals("Veg Pulao", r.name)
        assertEquals(listOf(ParsedIngredient("Basmati rice", "200", "g"), ParsedIngredient("Ginger garlic paste", "1", "tbsp"), ParsedIngredient("Salt", "to taste", "")), r.ingredients)
        assertEquals(listOf("Wash and soak the rice.", "Cook everything together."), r.steps)
        assertEquals("25 mins", r.cookTime)
    }

    @Test
    fun case10_unclassified_lines_are_kept_not_dropped() {
        // unclassified lines are kept, not dropped
        val r = parseRecipeText(listOf(
            "Tomato Soup",
            "Follow us on Instagram @tastykitchen",
            "Ingredients",
            "Tomato - 4",
            "Water - 2 cups",
            "Method",
            "1. Boil the tomatoes.",
            "www.tastykitchen.com"
        ))
        assertEquals("Tomato Soup", r.name)
        assertEquals(listOf(ParsedIngredient("Tomato", "4", ""), ParsedIngredient("Water", "2", "cups")), r.ingredients)
        assertEquals(listOf("Boil the tomatoes."), r.steps)
        assertTrue(r.unclassified.contains("Follow us on Instagram @tastykitchen"))
        assertTrue(r.unclassified.contains("www.tastykitchen.com"))
    }

    @Test
    fun case11_missing_times_and_serving_stay_blank() {
        // missing times and serving stay blank
        val r = parseRecipeText(listOf(
            "Lemon Water",
            "Ingredients",
            "Lemon - 1",
            "Water - 1 glass",
            "Method",
            "Squeeze the lemon into the water and stir."
        ))
        assertEquals(listOf(ParsedIngredient("Lemon", "1", ""), ParsedIngredient("Water", "1", "glass")), r.ingredients)
        assertEquals(listOf("Squeeze the lemon into the water and stir."), r.steps)
        assertEquals("", r.prepTime)
        assertEquals("", r.cookTime)
        assertEquals("", r.totalTime)
        assertEquals("", r.servings)
    }

    @Test
    fun case12_one_line_metadata() {
        // one-line metadata
        val r = parseRecipeText(listOf(
            "Paneer Bhurji",
            "Prep: 10 min | Cook: 15 min | Serves 4",
            "Total Time: 25 mins",
            "Ingredients",
            "Paneer - 200 g"
        ))
        assertEquals(listOf(ParsedIngredient("Paneer", "200", "g")), r.ingredients)
        assertEquals("10 min", r.prepTime)
        assertEquals("15 min", r.cookTime)
        assertEquals("25 mins", r.totalTime)
        assertEquals("4", r.servings)
    }

    @Test
    fun case13_instruction_like_line_inside_the_ingredient_list_becomes_a_step_not_an() {
        // instruction-like line inside the ingredient list becomes a step, not an ingredient
        val r = parseRecipeText(listOf(
            "Dal",
            "Ingredients",
            "Toor dal - 1 cup",
            "Water - 3 cups",
            "Cook for 5 minutes",
            "Method",
            "1. Pressure cook the dal."
        ))
        assertEquals(listOf(ParsedIngredient("Toor dal", "1", "cup"), ParsedIngredient("Water", "3", "cups")), r.ingredients)
        assertEquals(listOf("Cook for 5 minutes", "Pressure cook the dal."), r.steps)
    }

    @Test
    fun case14_names_column_then_quantities_column_text_only_equal_counts() {
        // names column then quantities column (text only, equal counts)
        val r = parseRecipeText(listOf(
            "Ingredients",
            "Paneer",
            "Green peas",
            "Onion",
            "250 g",
            "1 cup",
            "2",
            "Method",
            "1. Cook it all."
        ))
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Green peas", "1", "cup"), ParsedIngredient("Onion", "2", "")), r.ingredients)
        assertEquals(listOf("Cook it all."), r.steps)
    }

    @Test
    fun case15_quantities_that_cannot_be_paired_are_not_guessed() {
        // quantities that cannot be paired are not guessed
        val r = parseRecipeText(listOf(
            "Ingredients",
            "Paneer",
            "Onion",
            "250 g",
            "Method",
            "1. Cook."
        ))
        assertEquals(listOf(ParsedIngredient("Paneer", "", ""), ParsedIngredient("Onion", "", "")), r.ingredients)
        assertEquals(listOf("Cook."), r.steps)
        assertTrue(r.unclassified.contains("250 g"))
    }

    @Test
    fun case16_two_column_poster_ingredients_left_method_right_geometry() {
        // two-column poster: ingredients left, method right (geometry)
        val r = parseRecipe(listOf(
            OcrLine("MATAR PANEER", 200, 20, 800, 90, 0),
            OcrLine("INGREDIENTS", 40, 150, 300, 185, 1),
            OcrLine("Paneer - 250 g", 40, 200, 320, 230, 2),
            OcrLine("Green peas - 1 cup", 40, 235, 360, 265, 2),
            OcrLine("Onion - 2", 40, 270, 250, 300, 2),
            OcrLine("METHOD", 520, 150, 760, 185, 3),
            OcrLine("1. Heat oil in a pan.", 520, 200, 900, 230, 4),
            OcrLine("2. Add the onions and fry.", 520, 235, 940, 265, 4),
            OcrLine("3. Add peas and paneer.", 520, 270, 880, 300, 4)
        ))
        assertEquals("Matar Paneer", r.name)
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Green peas", "1", "cup"), ParsedIngredient("Onion", "2", "")), r.ingredients)
        assertEquals(listOf("Heat oil in a pan.", "Add the onions and fry.", "Add peas and paneer."), r.steps)
    }

    @Test
    fun case17_column_interleaving_in_OCR_order_is_repaired_by_layout() {
        // column interleaving in OCR order is repaired by layout
        val r = parseRecipe(listOf(
            OcrLine("1. Heat oil in a pan.", 520, 200, 900, 230, 4),
            OcrLine("Paneer - 250 g", 40, 200, 320, 230, 2),
            OcrLine("2. Add the onions and fry.", 520, 235, 940, 265, 4),
            OcrLine("Onion - 2", 40, 235, 250, 265, 2),
            OcrLine("METHOD", 520, 150, 760, 185, 3),
            OcrLine("INGREDIENTS", 40, 150, 300, 185, 1),
            OcrLine("BHURJI", 300, 20, 700, 90, 0)
        ))
        assertEquals("Bhurji", r.name)
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Onion", "2", "")), r.ingredients)
        assertEquals(listOf("Heat oil in a pan.", "Add the onions and fry."), r.steps)
    }

    @Test
    fun case18_ingredient_table_names_and_quantities_in_separate_columns_rows_aligned() {
        // ingredient table: names and quantities in separate columns, rows aligned
        val r = parseRecipe(listOf(
            OcrLine("CHAI MASALA", 200, 20, 800, 90, 0),
            OcrLine("INGREDIENTS", 40, 150, 400, 185, 1),
            OcrLine("Sugar", 40, 200, 160, 230, 2),
            OcrLine("Tea leaves", 40, 240, 230, 270, 2),
            OcrLine("Milk", 40, 280, 130, 310, 2),
            OcrLine("2 tbsp", 420, 202, 540, 232, 3),
            OcrLine("1 tsp", 420, 242, 520, 272, 3),
            OcrLine("1 cup", 420, 282, 520, 312, 3)
        ))
        assertEquals("Chai Masala", r.name)
        assertEquals(listOf(ParsedIngredient("Sugar", "2", "tbsp"), ParsedIngredient("Tea leaves", "1", "tsp"), ParsedIngredient("Milk", "1", "cup")), r.ingredients)
    }

    @Test
    fun case19_big_title_chosen_by_font_size_not_just_first_line() {
        // big title chosen by font size, not just first line
        val r = parseRecipe(listOf(
            OcrLine("Recipe Card", 30, 10, 200, 30, 0),
            OcrLine("PALAK PANEER", 150, 50, 850, 140, 1),
            OcrLine("Ingredients", 40, 200, 300, 230, 2),
            OcrLine("Palak - 500 g", 40, 240, 330, 270, 3)
        ))
        assertEquals("Palak Paneer", r.name)
        assertEquals(listOf(ParsedIngredient("Palak", "500", "g")), r.ingredients)
    }

    @Test
    fun case20_heading_variants_Ingredients_Required_Preparation_Method_Main_Ingredie() {
        // heading variants: Ingredients Required / Preparation Method / Main Ingredients
        val r = parseRecipeText(listOf(
            "Quick Upma",
            "Ingredients Required",
            "Semolina - 1 cup",
            "Water - 2 cups",
            "Main Ingredients",
            "Mustard seeds - 1 tsp",
            "Preparation Method",
            "1. Roast the semolina.",
            "2. Add water and cook.",
            "4 servings"
        ))
        assertEquals("Quick Upma", r.name)
        assertEquals(listOf(ParsedIngredient("Semolina", "1", "cup"), ParsedIngredient("Water", "2", "cups"), ParsedIngredient("Mustard seeds", "1", "tsp")), r.ingredients)
        assertEquals(listOf("Roast the semolina.", "Add water and cook."), r.steps)
        assertEquals("4 servings", r.servings)
    }

    @Test
    fun case21_Hindi_metadata_labels() {
        // Hindi metadata labels
        val r = parseRecipeText(listOf(
            "दाल फ्राई",
            "कितने लोगों के लिए: 4",
            "पकाने का समय: 30 मिनट",
            "कुल समय - 45 मिनट"
        ))
        assertEquals("दाल फ्राई", r.name)
        assertEquals("30 मिनट", r.cookTime)
        assertEquals("45 मिनट", r.totalTime)
        assertEquals("4", r.servings)
    }

    @Test
    fun case22_orphan_step_numbers_from_the_OCR_engine_are_not_kept_as_junk() {
        // orphan step numbers from the OCR engine are not kept as junk
        val r = parseRecipeText(listOf(
            "Method",
            "1",
            "Heat the oil in a pan.",
            "2",
            "Add the onions and fry."
        ))
        assertEquals(listOf("Heat the oil in a pan.", "Add the onions and fry."), r.steps)
        assertEquals(listOf(), r.unclassified)
    }

    @Test
    fun case23_approximately_before_a_quantity_keeps_the_wording() {
        // approximately before a quantity keeps the wording
        val r = parseRecipeText(listOf(
            "Ingredients",
            "Water approximately 200 ml",
            "Oil - approx. 2 tbsp"
        ))
        assertEquals(listOf(ParsedIngredient("Water", "approximately 200", "ml"), ParsedIngredient("Oil", "approx 2", "tbsp")), r.ingredients)
    }

    @Test
    fun case24_real_Tesseract_output_poster_with_two_columns_merged_into_single_lines() {
        // real Tesseract output: poster with two columns merged into single lines
        val r = parseRecipe(listOf(
            OcrLine("DHABA STYLE MATAR PANEER", 126, 52, 1187, 101, 1, listOf(OcrWord("DHABA", 126, 53, 374, 100), OcrWord("STYLE", 402, 52, 613, 101), OcrWord("MATAR", 646, 53, 884, 100), OcrWord("PANEER", 914, 53, 1187, 100))),
            OcrLine("INGREDIENTS METHOD", 64, 194, 953, 240, 2, listOf(OcrWord("INGREDIENTS", 64, 194, 362, 240), OcrWord("METHOD", 764, 198, 953, 228))),
            OcrLine("Paneer - 250g 1. Heat the oil in a pan.", 63, 266, 1156, 299, 2, listOf(OcrWord("Paneer", 63, 267, 177, 292), OcrWord("-", 190, 281, 199, 284), OcrWord("250g", 213, 267, 306, 299), OcrWord("1.", 764, 267, 789, 292), OcrWord("Heat", 806, 267, 884, 292), OcrWord("the", 896, 266, 949, 292), OcrWord("oil", 963, 266, 998, 292), OcrWord("in", 1015, 266, 1040, 292), OcrWord("a", 1056, 273, 1072, 292), OcrWord("pan.", 1088, 273, 1156, 299))),
            OcrLine("Green peas - 1 cup 2. Add chopped onions and", 62, 328, 1221, 361, 2, listOf(OcrWord("Green", 62, 329, 160, 354), OcrWord("peas", 177, 335, 253, 361), OcrWord("-", 268, 343, 277, 346), OcrWord("1", 293, 329, 308, 354), OcrWord("cup", 323, 335, 381, 361), OcrWord("2.", 762, 329, 789, 354), OcrWord("Add", 803, 328, 867, 354), OcrWord("chopped", 882, 328, 1024, 361), OcrWord("onions", 1039, 328, 1148, 354), OcrWord("and", 1162, 328, 1221, 354))),
            OcrLine("Onion - 2 fry until golden.", 62, 390, 1069, 423, 2, listOf(OcrWord("Onion", 62, 390, 158, 416), OcrWord("-", 173, 405, 182, 408), OcrWord("2", 196, 391, 212, 416), OcrWord("fry", 804, 390, 848, 423), OcrWord("until", 863, 390, 932, 416), OcrWord("golden.", 948, 390, 1069, 423))),
            OcrLine("Tomato - 2 3. Add the tomatoes and the", 60, 452, 1247, 478, 2, listOf(OcrWord("Tomato", 60, 453, 182, 478), OcrWord("-", 197, 467, 206, 470), OcrWord("2", 220, 453, 236, 478), OcrWord("3.", 763, 453, 789, 478), OcrWord("Add", 803, 452, 867, 478), OcrWord("the", 881, 452, 934, 478), OcrWord("tomatoes", 948, 454, 1106, 478), OcrWord("and", 1120, 452, 1180, 478), OcrWord("the", 1194, 452, 1247, 478))),
            OcrLine("Ginger garlic paste - 1 tbsp masala and cook well.", 62, 514, 1177, 547, 2, listOf(OcrWord("Ginger", 62, 514, 174, 547), OcrWord("garlic", 187, 514, 277, 547), OcrWord("paste", 292, 516, 382, 547), OcrWord("-", 397, 529, 406, 532), OcrWord("1", 422, 515, 437, 540), OcrWord("tbsp", 451, 514, 523, 547), OcrWord("masala", 806, 514, 923, 540), OcrWord("and", 939, 514, 998, 540), OcrWord("cook", 1014, 514, 1091, 540), OcrWord("well.", 1103, 514, 1177, 540))),
            OcrLine("Oil - 2 tbsp 4. Add peas and paneer.", 62, 576, 1170, 609, 2, listOf(OcrWord("Oil", 62, 576, 102, 602), OcrWord("-", 118, 591, 127, 594), OcrWord("2", 142, 577, 158, 602), OcrWord("tbsp", 173, 576, 245, 609), OcrWord("4.", 762, 577, 789, 602), OcrWord("Add", 803, 576, 867, 602), OcrWord("peas", 883, 583, 959, 609), OcrWord("and", 974, 576, 1033, 602), OcrWord("paneer.", 1050, 583, 1170, 609))),
            OcrLine("Salt - to taste 5. Simmer for 10 minutes.", 62, 638, 1203, 664, 2, listOf(OcrWord("Salt", 62, 638, 125, 664), OcrWord("-", 138, 653, 147, 656), OcrWord("to", 160, 640, 191, 664), OcrWord("taste", 205, 640, 288, 664), OcrWord("5.", 763, 639, 789, 664), OcrWord("Simmer", 805, 638, 935, 664), OcrWord("for", 947, 638, 993, 664), OcrWord("10", 1008, 639, 1044, 664), OcrWord("minutes.", 1061, 638, 1203, 664))),
            OcrLine("Cooking Time: 30 minutes", 62, 806, 558, 839, 3, listOf(OcrWord("Cooking", 62, 806, 212, 839), OcrWord("Time:", 226, 806, 330, 832), OcrWord("30", 347, 807, 391, 832), OcrWord("minutes", 407, 806, 558, 832))),
            OcrLine("Serves: 3-4", 62, 867, 275, 892, 4, listOf(OcrWord("Serves:", 62, 867, 200, 892), OcrWord("3-4", 217, 867, 275, 892)))
        ))
        assertEquals("Dhaba Style Matar Paneer", r.name)
        assertEquals(listOf(ParsedIngredient("Paneer", "250", "g"), ParsedIngredient("Green peas", "1", "cup"), ParsedIngredient("Onion", "2", ""), ParsedIngredient("Tomato", "2", ""), ParsedIngredient("Ginger garlic paste", "1", "tbsp"), ParsedIngredient("Oil", "2", "tbsp"), ParsedIngredient("Salt", "to taste", "")), r.ingredients)
        assertEquals(listOf("Heat the oil in a pan.", "Add chopped onions and fry until golden.", "Add the tomatoes and the masala and cook well.", "Add peas and paneer.", "Simmer for 10 minutes."), r.steps)
        assertEquals("30 minutes", r.cookTime)
        assertEquals("3-4", r.servings)
        assertEquals(listOf(), r.unclassified)
    }

    @Test
    fun case25_real_Tesseract_output_ingredient_table_with_quantities_in_a_second_col() {
        // real Tesseract output: ingredient table with quantities in a second column
        val r = parseRecipe(listOf(
            OcrLine("MASALA CHAI", 106, 53, 636, 106, 1, listOf(OcrWord("MASALA", 106, 53, 427, 106), OcrWord("CHAI", 455, 53, 636, 106))),
            OcrLine("Ingredients", 64, 177, 331, 218, 2, listOf(OcrWord("Ingredients", 64, 177, 331, 218))),
            OcrLine("Water 2 cups", 61, 248, 767, 281, 2, listOf(OcrWord("Water", 61, 248, 167, 274), OcrWord("2", 653, 248, 669, 274), OcrWord("cups", 686, 254, 767, 281))),
            OcrLine("Tea leaves 1 tsp", 60, 307, 738, 341, 2, listOf(OcrWord("Tea", 60, 308, 117, 334), OcrWord("leaves", 135, 307, 246, 334), OcrWord("1", 654, 308, 670, 334), OcrWord("tsp", 685, 308, 738, 341))),
            OcrLine("Sugar 2 tsp", 62, 368, 738, 401, 2, listOf(OcrWord("Sugar", 62, 368, 166, 401), OcrWord("2", 653, 368, 669, 394), OcrWord("tsp", 685, 368, 738, 401))),
            OcrLine("Milk 1 cup", 63, 423, 748, 465, 2, listOf(OcrWord("Milk", 63, 423, 131, 465), OcrWord("1", 654, 428, 670, 454), OcrWord("cup", 686, 434, 748, 461))),
            OcrLine("Ginger 1 inch", 62, 487, 757, 521, 2, listOf(OcrWord("Ginger", 62, 487, 181, 521), OcrWord("1", 654, 488, 670, 514), OcrWord("inch", 687, 487, 757, 514))),
            OcrLine("Method", 64, 587, 236, 619, 2, listOf(OcrWord("Method", 64, 587, 236, 619))),
            OcrLine("1. Boil the water with ginger.", 64, 657, 576, 691, 3, listOf(OcrWord("1.", 64, 658, 91, 684), OcrWord("Boil", 109, 657, 170, 684), OcrWord("the", 185, 657, 241, 684), OcrWord("water", 256, 658, 357, 684), OcrWord("with", 370, 657, 442, 684), OcrWord("ginger.", 458, 657, 576, 691))),
            OcrLine("2. Add tea leaves and sugar.", 63, 717, 570, 751, 3, listOf(OcrWord("2.", 63, 718, 91, 744), OcrWord("Add", 106, 717, 173, 744), OcrWord("tea", 188, 718, 242, 744), OcrWord("leaves", 260, 717, 371, 744), OcrWord("and", 387, 717, 449, 744), OcrWord("sugar.", 466, 724, 570, 751))),
            OcrLine("3. Pour in the milk and simmer.", 63, 777, 619, 804, 3, listOf(OcrWord("3.", 63, 778, 91, 804), OcrWord("Pour", 109, 778, 186, 804), OcrWord("in", 200, 777, 227, 804), OcrWord("the", 243, 777, 298, 804), OcrWord("milk", 315, 777, 387, 804), OcrWord("and", 401, 777, 464, 804), OcrWord("simmer.", 481, 777, 619, 804)))
        ))
        assertEquals("Masala Chai", r.name)
        assertEquals(listOf(ParsedIngredient("Water", "2", "cups"), ParsedIngredient("Tea leaves", "1", "tsp"), ParsedIngredient("Sugar", "2", "tsp"), ParsedIngredient("Milk", "1", "cup"), ParsedIngredient("Ginger", "1", "inch")), r.ingredients)
        assertEquals(listOf("Boil the water with ginger.", "Add tea leaves and sugar.", "Pour in the milk and simmer."), r.steps)
    }

    @Test
    fun originalOcrTextIsNotTouchedByTheParser() {
        val raw = listOf("Tomato Soup", "Follow us on Instagram @tastykitchen", "Ingredients", "Tomato - 4")
        val before = raw.toList()
        parseRecipeText(raw)
        assertEquals(before, raw)
    }

    @Test
    fun everyInputLineEndsUpSomewhere() {
        val raw = listOf("Tomato Soup", "Ingredients", "Tomato - 4", "Method", "1. Boil the tomatoes.", "random unknown words here")
        val r = parseRecipeText(raw)
        val seen = r.ingredients.size + r.steps.size + r.unclassified.size + (if (r.name.isNotEmpty()) 1 else 0)
        assertTrue(seen >= 4)
        assertTrue(r.unclassified.contains("random unknown words here") || r.steps.any { it.contains("random") })
    }
}
